import pandas as pd

from acre_gformer.data.splits import assert_no_entity_leakage, scaffold_group_folds


def test_entity_grouping_is_preserved():
    rows = []
    for group in range(10):
        for repeat in range(2):
            rows.append(
                {
                    "entity_id": f"entity_{group}",
                    "scaffold": f"scaffold_{group}",
                    "task": "repellency_ordinal" if group % 2 == 0 else "sensitization_binary",
                    "label": group % 2 if group % 2 else (group % 5) + 1,
                    "repeat": repeat,
                }
            )
    frame = pd.DataFrame(rows)
    frame["outer_fold"] = scaffold_group_folds(frame, n_splits=5)
    assert_no_entity_leakage(frame, "entity_id", "outer_fold")
    assert frame.groupby("entity_id")["outer_fold"].nunique().max() == 1
