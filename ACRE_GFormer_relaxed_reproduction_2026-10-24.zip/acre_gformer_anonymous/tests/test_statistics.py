import numpy as np

from acre_gformer.evaluation.statistics import cliffs_delta, cliffs_magnitude, holm_adjust


def test_holm_joint_six_matches_manuscript_values():
    adjusted = holm_adjust([0.002, 0.0001, 0.009, 0.004, 0.401, 0.518])
    assert np.allclose(adjusted, [0.010, 0.0006, 0.027, 0.016, 0.802, 0.802])


def test_cliffs_delta_direction_and_magnitude():
    value = cliffs_delta(np.array([2.0, 3.0, 4.0]), np.array([1.0, 2.0, 3.0]))
    assert value > 0
    assert cliffs_magnitude(0.10) == "negligible"
    assert cliffs_magnitude(0.20) == "small"
