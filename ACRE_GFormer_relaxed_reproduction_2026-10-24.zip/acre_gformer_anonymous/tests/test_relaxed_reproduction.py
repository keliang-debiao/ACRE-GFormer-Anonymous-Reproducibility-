from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "10_reproduce_relaxed.py"


def load_script_module():
    specification = importlib.util.spec_from_file_location("relaxed_reproduction", SCRIPT)
    assert specification is not None and specification.loader is not None
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def test_relaxed_reproduction_targets_pass():
    module = load_script_module()
    tables = module.load_tables(ROOT / "reference_outputs" / "metrics")
    checks = module.build_checks(tables)
    assert len(checks) >= 10
    assert all(check.status == "PASS" for check in checks)
