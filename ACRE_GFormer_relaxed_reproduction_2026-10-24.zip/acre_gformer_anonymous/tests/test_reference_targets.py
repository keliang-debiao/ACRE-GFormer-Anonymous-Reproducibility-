from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]


def test_repellency_fold_summary_is_exact():
    frame = pd.read_csv(ROOT / "reference_outputs/metrics/internal_repellency_cv.csv")
    folds = frame[frame["split"].str.startswith("fold_")]
    assert np.isclose(folds["qwk"].mean(), 0.640, atol=0.0005)
    assert np.isclose(folds["qwk"].std(ddof=1), 0.009, atol=0.0005)
    assert np.isclose(folds["auroc"].mean(), 0.843, atol=0.0005)


def test_sensitization_fold_summary_is_exact():
    frame = pd.read_csv(ROOT / "reference_outputs/metrics/internal_sensitization_cv.csv")
    folds = frame[frame["split"].str.startswith("fold_")]
    assert np.isclose(folds["auprc"].mean(), 0.469, atol=0.0005)
    assert np.isclose(folds["mcc"].mean(), 0.402, atol=0.0005)
