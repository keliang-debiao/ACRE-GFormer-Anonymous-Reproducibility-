from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]


def test_frozen_configuration_matches_declared_architecture():
    config = yaml.safe_load((ROOT / "configs/main.yaml").read_text(encoding="utf-8"))
    assert config["model"]["layers"] == 5
    assert config["model"]["hidden_dim"] == 256
    assert config["model"]["heads"] == 8
    assert config["model"]["experts"] == 3
    assert config["model"]["top_k"] == 2
    assert config["training"]["seeds"] == [2026, 2027, 2028, 2029, 2030]
    assert config["evaluation"]["multiple_testing"] == "holm_joint_six"
