# ACRE GFormer Anonymous Reproducibility Repository

This repository implements the complete analysis pipeline for **ACRE GFormer for Assay-Conditioned and Uncertainty-Calibrated Prediction of Mosquito Repellency and Skin-Sensitization Alerts**.

The package covers public-data ingestion, structure standardization, entity-aware scaffold splitting, nested model selection, multi-task graph learning, calibration, conformal prediction, external transfer evaluation, ablation, robustness, statistical comparison, interpretability, efficiency measurement, and figure/table export.

## Scope

The model predicts molecular endpoints from two-dimensional chemical structure and observed assay context. It does not model gel release, rheology, formulation stability, mixture interactions, exposure, irritation, or complete dermal safety.

## Repository layout

- `configs/`: data contracts, model settings, baseline settings, and experiment plans.
- `src/acre_gformer/`: reusable implementation modules.
- `scripts/`: numbered entry points matching the manuscript workflow.
- `tests/`: unit and leakage-control checks.
- `reference_outputs/`: manuscript-aligned target tables and a clearly identified reference trace.
- `verification/`: package checks produced during assembly.
- `data/`: empty local data locations; public source records are not redistributed.
- `outputs/`: generated folds, checkpoints, predictions, metrics, plots, and logs.

## Data access

Acquire the three public sources identified in `configs/data_sources.yaml` from their official landing pages. Place the downloaded files under `data/raw/` and record the local filename and SHA-256 value in the configuration. The preparation script accepts CSV, TSV, XLSX, SDF, and SMILES tables and writes a normalized record table plus a molecular registry.

The repository does not claim that data landing pages expose stable direct-download URLs. This avoids hard-coding transient links. All imported files are checksum recorded before parsing.

## Environment

Python 3.11 is required. GPU training is recommended.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

## Core model run

```bash
bash scripts/run_all.sh configs/main.yaml
```

## Relaxed result-alignment reproduction

When the goal is to verify that the manuscript tables and figures align with the supplied
reference targets, run the permissive reconstruction protocol:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/run_relaxed.ps1
```

This command recomputes the reported five-fold summaries from the supplied fold rows, verifies
the principal internal, transfer, calibration, and ablation values, rebuilds Figures 3–8, records
SHA-256 fingerprints for every reference table, and runs the test suite. Outputs are written to
`outputs/relaxed_reproduction/`.

The relaxed protocol is a reference-target reconstruction, not independent raw-data retraining.
Formal execution evidence still requires the public source files, resolved column mappings, source
checksums, and the numbered end-to-end training stages described below.

The numbered scripts can also be run separately. Stages 06–09 accept the declared run-generated artifacts so that robustness, statistical, interpretation, efficiency, and figure outputs remain traceable to a specific completed run:

```bash
python scripts/00_validate_sources.py --config configs/main.yaml
python scripts/01_prepare_data.py --config configs/main.yaml
python scripts/02_make_splits.py --config configs/main.yaml
python scripts/03_train_nested_cv.py --config configs/main.yaml
python scripts/04_external_transfer.py --config configs/main.yaml
python scripts/05_run_ablations.py --config configs/main.yaml
python scripts/06_run_robustness.py --config configs/main.yaml
python scripts/07_statistics.py --config configs/main.yaml
python scripts/08_interpretability_efficiency.py --config configs/main.yaml
python scripts/09_build_figures.py --config configs/main.yaml
```

## Leakage controls

1. Canonical parent structure is registered before splitting.
2. Records sharing a molecular entity remain in the same outer fold across tasks.
3. Bemis-Murcko scaffold groups define the outer split.
4. Imputation, scaling, feature filtering, resampling, calibration, threshold selection, and model selection are fitted only within the current training partition.
5. Transfer-set overlaps are removed by standardized InChIKey before scoring.
6. Transfer labels never enter fitting, calibration, threshold selection, or conformity-quantile estimation.

## Reference targets and run evidence

Files under `reference_outputs/` reproduce the values reported in the manuscript and define expected pipeline targets. They are **not original execution records** and must not be represented as such. Formal run evidence is created only when the scripts execute against the public source files. Each run receives a timestamped directory containing configuration snapshots, dependency metadata, split hashes, metrics, and console logs.

## Anonymous review

No author names, affiliations, local machine paths, credentials, private data, or repository-owner identifiers are included. The package contains no external tracking code.

## License

Code is released under the MIT License. Source datasets retain their original licenses and terms.
