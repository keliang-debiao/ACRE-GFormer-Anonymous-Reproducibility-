from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from acre_gformer.evaluation.metrics import binary_metrics, ordinal_metrics


ORDINAL_COLUMNS = [f"ordinal_p{level}" for level in range(1, 6)]


def latest_stage(output_root: str | Path, suffix: str) -> Path:
    candidates = sorted(Path(output_root).glob(f"*_{suffix}"))
    if not candidates:
        raise FileNotFoundError(f"No completed stage directory ending in {suffix}")
    return candidates[-1]


def fold_metric_table(predictions: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    ordinal_rows: list[dict[str, float]] = []
    sensitization_rows: list[dict[str, float]] = []
    for fold in sorted(predictions["outer_fold"].unique()):
        fold_frame = predictions[predictions["outer_fold"] == fold]
        ordinal = fold_frame[fold_frame["task"] == "repellency_ordinal"]
        sensitization = fold_frame[fold_frame["task"] == "sensitization_binary"]
        ordinal_result = ordinal_metrics(
            ordinal["label"].to_numpy(), ordinal[ORDINAL_COLUMNS].to_numpy()
        )
        ordinal_rows.append({"fold": int(fold) + 1, **ordinal_result})
        threshold = 0.5
        sensitization_result = binary_metrics(
            sensitization["label"].to_numpy(),
            sensitization["sensitization_probability"].to_numpy(),
            threshold,
        )
        sensitization_rows.append({"fold": int(fold) + 1, **sensitization_result})
    return pd.DataFrame(ordinal_rows), pd.DataFrame(sensitization_rows)


def append_mean_sd_ci(frame: pd.DataFrame) -> pd.DataFrame:
    metrics = [column for column in frame.columns if column != "fold"]
    summary: list[dict[str, object]] = []
    mean_row: dict[str, object] = {"fold": "mean"}
    sd_row: dict[str, object] = {"fold": "sd"}
    lower_row: dict[str, object] = {"fold": "ci_lower"}
    upper_row: dict[str, object] = {"fold": "ci_upper"}
    for metric in metrics:
        values = frame[metric].to_numpy(dtype=float)
        mean = float(values.mean())
        sd = float(values.std(ddof=1))
        margin = float(stats.t.ppf(0.975, len(values) - 1) * sd / np.sqrt(len(values)))
        mean_row[metric] = mean
        sd_row[metric] = sd
        lower_row[metric] = mean - margin
        upper_row[metric] = mean + margin
    summary.extend([mean_row, sd_row, lower_row, upper_row])
    return pd.concat([frame, pd.DataFrame(summary)], ignore_index=True)


def summarize_oof(prediction_path: str | Path, output_dir: str | Path) -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions = pd.read_parquet(prediction_path)
    ordinal, sensitization = fold_metric_table(predictions)
    append_mean_sd_ci(ordinal).to_csv(output_dir / "internal_repellency_metrics.csv", index=False)
    append_mean_sd_ci(sensitization).to_csv(
        output_dir / "internal_sensitization_metrics.csv", index=False
    )
