from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


class MonotoneOrdinalHead(nn.Module):
    def __init__(self, hidden_dim: int = 256, levels: int = 5) -> None:
        super().__init__()
        if levels < 2:
            raise ValueError("Ordinal levels must be at least two")
        self.levels = levels
        self.score = nn.Linear(hidden_dim, 1)
        self.delta = nn.Parameter(torch.zeros(levels - 1))

    def thresholds(self) -> torch.Tensor:
        first = self.delta[:1]
        if self.delta.numel() == 1:
            return first
        increments = F.softplus(self.delta[1:]) + 1e-4
        return torch.cat([first, first + torch.cumsum(increments, dim=0)])

    def forward(self, h: torch.Tensor) -> dict[str, torch.Tensor]:
        score = self.score(h).squeeze(-1)
        thresholds = self.thresholds()
        cumulative = torch.sigmoid(score.unsqueeze(-1) - thresholds.unsqueeze(0))
        classes = [1.0 - cumulative[:, :1]]
        if self.levels > 2:
            classes.append(cumulative[:, :-1] - cumulative[:, 1:])
        classes.append(cumulative[:, -1:])
        probabilities = torch.cat(classes, dim=-1).clamp_min(0.0)
        probabilities = probabilities / probabilities.sum(dim=-1, keepdim=True).clamp_min(1e-12)
        high_probability = cumulative[:, 2] if self.levels == 5 else cumulative[:, -2]
        return {
            "latent_score": score,
            "thresholds": thresholds,
            "cumulative": cumulative,
            "class_probabilities": probabilities,
            "high_repellency_probability": high_probability,
        }


class BinaryHead(nn.Module):
    def __init__(self, hidden_dim: int = 256) -> None:
        super().__init__()
        self.linear = nn.Linear(hidden_dim, 1)

    def forward(self, h: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        logits = self.linear(h).squeeze(-1)
        return logits, torch.sigmoid(logits)
