from __future__ import annotations

import math

import torch
from torch import nn
from torch_geometric.utils import scatter, softmax


class AssayConditionedGraphLayer(nn.Module):
    def __init__(
        self,
        hidden_dim: int,
        heads: int,
        edge_dim: int,
        distance_buckets: int,
        feedforward_dim: int,
        dropout: float,
        condition_in_attention: bool = True,
    ) -> None:
        super().__init__()
        if hidden_dim % heads:
            raise ValueError("hidden_dim must be divisible by heads")
        self.hidden_dim = hidden_dim
        self.heads = heads
        self.head_dim = hidden_dim // heads
        self.condition_in_attention = condition_in_attention
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.norm2 = nn.LayerNorm(hidden_dim)
        self.query = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.key = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.value = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.edge_bias = nn.Linear(edge_dim, heads, bias=False)
        self.distance_bias = nn.Embedding(distance_buckets, heads)
        self.context_query = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.context_key = nn.Linear(hidden_dim, hidden_dim, bias=False)
        self.output = nn.Linear(hidden_dim, hidden_dim)
        self.dropout = nn.Dropout(dropout)
        self.feedforward = nn.Sequential(
            nn.Linear(hidden_dim, feedforward_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(feedforward_dim, hidden_dim),
            nn.Dropout(dropout),
        )

    def forward(
        self,
        x: torch.Tensor,
        edge_index: torch.Tensor,
        edge_repr: torch.Tensor,
        distance_bucket: torch.Tensor,
        context: torch.Tensor,
        batch: torch.Tensor,
    ) -> torch.Tensor:
        residual = x
        normalized = self.norm1(x)
        q = self.query(normalized).view(-1, self.heads, self.head_dim)
        k = self.key(normalized).view(-1, self.heads, self.head_dim)
        v = self.value(normalized).view(-1, self.heads, self.head_dim)
        src, dst = edge_index
        score = (q[dst] * k[src]).sum(dim=-1) / math.sqrt(self.head_dim)
        score = score + self.edge_bias(edge_repr) + self.distance_bias(distance_bucket)
        if self.condition_in_attention:
            condition = context[batch[dst]]
            cq = self.context_query(condition).view(-1, self.heads, self.head_dim)
            ck = self.context_key(normalized[src]).view(-1, self.heads, self.head_dim)
            score = score + (cq * ck).sum(dim=-1) / math.sqrt(self.head_dim)
        weights = softmax(score, dst)
        message = weights.unsqueeze(-1) * v[src]
        aggregated = scatter(message, dst, dim=0, dim_size=x.size(0), reduce="sum")
        aggregated = aggregated.reshape(-1, self.hidden_dim)
        x = residual + self.dropout(self.output(aggregated))
        return x + self.feedforward(self.norm2(x))
