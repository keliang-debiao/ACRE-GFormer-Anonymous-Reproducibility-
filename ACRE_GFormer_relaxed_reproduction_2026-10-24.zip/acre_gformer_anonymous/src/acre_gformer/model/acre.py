from __future__ import annotations

from typing import Any

import torch
from torch import nn

from .attention import AssayConditionedGraphLayer
from .encoders import ContextEncoder, InputEncoder
from .experts import TopKSparseExperts
from .heads import BinaryHead, MonotoneOrdinalHead
from .pooling import GatedAttentionPool


class ReconstructionHeads(nn.Module):
    def __init__(self, hidden_dim: int, atom_cardinalities: list[int], bond_cardinalities: list[int]) -> None:
        super().__init__()
        self.atom_heads = nn.ModuleList([nn.Linear(hidden_dim, size) for size in atom_cardinalities])
        self.bond_heads = nn.ModuleList([nn.Linear(hidden_dim, size) for size in bond_cardinalities])

    def forward(
        self,
        nodes: torch.Tensor,
        edge_index: torch.Tensor,
        edge_repr: torch.Tensor,
    ) -> dict[str, list[torch.Tensor]]:
        src, dst = edge_index
        bond_state = (nodes[src] + nodes[dst] + edge_repr) / 3.0
        return {
            "atom_reconstruction_logits": [head(nodes) for head in self.atom_heads],
            "bond_reconstruction_logits": [head(bond_state) for head in self.bond_heads],
        }


class ACREGFormer(nn.Module):
    def __init__(
        self,
        context_cardinalities: list[int],
        hidden_dim: int = 256,
        context_field_dim: int = 32,
        layers: int = 5,
        heads: int = 8,
        feedforward_dim: int = 512,
        distance_buckets: int = 7,
        experts: int = 3,
        top_k: int = 2,
        dropout: float = 0.15,
        pe_dim: int = 16,
        condition_in_attention: bool = True,
    ) -> None:
        super().__init__()
        self.input_encoder = InputEncoder(hidden_dim, pe_dim)
        self.context_encoder = ContextEncoder(context_cardinalities, context_field_dim, hidden_dim)
        self.layers = nn.ModuleList(
            [
                AssayConditionedGraphLayer(
                    hidden_dim,
                    heads,
                    hidden_dim,
                    distance_buckets,
                    feedforward_dim,
                    dropout,
                    condition_in_attention,
                )
                for _ in range(layers)
            ]
        )
        self.pool = GatedAttentionPool(hidden_dim)
        self.experts = TopKSparseExperts(
            input_dim=2 * hidden_dim,
            hidden_dim=feedforward_dim,
            output_dim=hidden_dim,
            experts=experts,
            top_k=top_k,
            dropout=dropout,
        )
        self.ordinal_head = MonotoneOrdinalHead(hidden_dim, levels=5)
        self.sensitization_head = BinaryHead(hidden_dim)
        from acre_gformer.data.graph import ATOM_CARDINALITIES, BOND_CARDINALITIES

        self.reconstruction_heads = ReconstructionHeads(
            hidden_dim, ATOM_CARDINALITIES, BOND_CARDINALITIES
        )

    def forward(self, batch: Any, return_reconstruction: bool = False) -> dict[str, torch.Tensor]:
        context = self.context_encoder(batch.context)
        x, edge_repr = self.input_encoder(batch.x, batch.edge_attr, batch.lap_pe)
        for layer in self.layers:
            x = layer(
                x,
                batch.edge_index,
                edge_repr,
                batch.distance_bucket,
                context,
                batch.batch,
            )
        graph = self.pool(x, batch.batch)
        joint = torch.cat([graph, context], dim=-1)
        h, gate, balance_loss = self.experts(joint)
        ordinal = self.ordinal_head(h)
        sensitization_logit, sensitization_probability = self.sensitization_head(h)
        result = {
            **ordinal,
            "sensitization_logit": sensitization_logit,
            "sensitization_probability": sensitization_probability,
            "expert_gate": gate,
            "balance_loss": balance_loss,
            "representation": h,
        }
        if return_reconstruction:
            result.update(self.reconstruction_heads(x, batch.edge_index, edge_repr))
        return result
