from __future__ import annotations

import torch
from torch import nn
from torch_geometric.utils import scatter, softmax


class GatedAttentionPool(nn.Module):
    def __init__(self, hidden_dim: int) -> None:
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x: torch.Tensor, batch: torch.Tensor) -> torch.Tensor:
        score = self.gate(x).squeeze(-1)
        weights = softmax(score, batch)
        return scatter(weights.unsqueeze(-1) * x, batch, dim=0, reduce="sum")
