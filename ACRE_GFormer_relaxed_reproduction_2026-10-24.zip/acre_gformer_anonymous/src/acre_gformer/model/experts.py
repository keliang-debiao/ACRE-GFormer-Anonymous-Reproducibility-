from __future__ import annotations

import torch
from torch import nn


class ExpertMLP(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, output_dim: int, dropout: float) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, output_dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x)


class TopKSparseExperts(nn.Module):
    def __init__(
        self,
        input_dim: int = 512,
        hidden_dim: int = 512,
        output_dim: int = 256,
        experts: int = 3,
        top_k: int = 2,
        dropout: float = 0.15,
    ) -> None:
        super().__init__()
        if not 1 <= top_k <= experts:
            raise ValueError("top_k must be within the expert count")
        self.expert_count = experts
        self.top_k = top_k
        self.gate = nn.Linear(input_dim, experts)
        self.experts = nn.ModuleList(
            [ExpertMLP(input_dim, hidden_dim, output_dim, dropout) for _ in range(experts)]
        )

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        logits = self.gate(x)
        probabilities = torch.softmax(logits, dim=-1)
        top_values, top_indices = torch.topk(probabilities, self.top_k, dim=-1)
        top_values = top_values / top_values.sum(dim=-1, keepdim=True)
        expert_stack = torch.stack([expert(x) for expert in self.experts], dim=1)
        selected = torch.gather(
            expert_stack,
            1,
            top_indices.unsqueeze(-1).expand(-1, -1, expert_stack.size(-1)),
        )
        output = (selected * top_values.unsqueeze(-1)).sum(dim=1)
        mean_use = probabilities.mean(dim=0)
        balance_loss = self.expert_count * ((mean_use - 1.0 / self.expert_count) ** 2).sum()
        return output, probabilities, balance_loss
