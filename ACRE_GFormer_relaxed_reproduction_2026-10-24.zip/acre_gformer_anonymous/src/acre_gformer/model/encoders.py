from __future__ import annotations

import torch
from torch import nn

from acre_gformer.data.graph import ATOM_CARDINALITIES, BOND_CARDINALITIES


class CategoricalSumEncoder(nn.Module):
    def __init__(self, cardinalities: list[int], dim: int) -> None:
        super().__init__()
        self.embeddings = nn.ModuleList([nn.Embedding(size, dim) for size in cardinalities])

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        if values.ndim != 2 or values.size(1) != len(self.embeddings):
            raise ValueError("Categorical feature tensor has incompatible shape")
        encoded = [embedding(values[:, index]) for index, embedding in enumerate(self.embeddings)]
        return torch.stack(encoded, dim=0).sum(dim=0)


class InputEncoder(nn.Module):
    def __init__(self, hidden_dim: int = 256, pe_dim: int = 16) -> None:
        super().__init__()
        self.atom = CategoricalSumEncoder(ATOM_CARDINALITIES, hidden_dim)
        self.bond = CategoricalSumEncoder(BOND_CARDINALITIES, hidden_dim)
        self.pe = nn.Linear(pe_dim, hidden_dim, bias=False)

    def forward(
        self, atom_features: torch.Tensor, bond_features: torch.Tensor, lap_pe: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if self.training:
            signs = torch.where(
                torch.rand(lap_pe.size(1), device=lap_pe.device) < 0.5,
                -torch.ones(lap_pe.size(1), device=lap_pe.device),
                torch.ones(lap_pe.size(1), device=lap_pe.device),
            )
        else:
            signs = torch.ones(lap_pe.size(1), device=lap_pe.device)
        nodes = self.atom(atom_features) + self.pe(lap_pe * signs)
        edges = self.bond(bond_features)
        return nodes, edges


class ContextEncoder(nn.Module):
    def __init__(
        self,
        cardinalities: list[int],
        field_dim: int = 32,
        output_dim: int = 256,
    ) -> None:
        super().__init__()
        self.embeddings = nn.ModuleList([nn.Embedding(size, field_dim) for size in cardinalities])
        self.projection = nn.Sequential(
            nn.Linear(field_dim * len(cardinalities), output_dim),
            nn.LayerNorm(output_dim),
            nn.GELU(),
        )

    def forward(self, context: torch.Tensor) -> torch.Tensor:
        fields = [embedding(context[:, index]) for index, embedding in enumerate(self.embeddings)]
        return self.projection(torch.cat(fields, dim=-1))
