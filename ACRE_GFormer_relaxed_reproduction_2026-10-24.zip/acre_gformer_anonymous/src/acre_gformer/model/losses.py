from __future__ import annotations

import torch
from torch.nn import functional as F


def reconstruction_loss(
    atom_logits: list[torch.Tensor],
    bond_logits: list[torch.Tensor],
    atom_targets: torch.Tensor,
    bond_targets: torch.Tensor,
    atom_mask: torch.Tensor,
    bond_mask: torch.Tensor,
) -> torch.Tensor:
    terms: list[torch.Tensor] = []
    if atom_mask.any():
        atom_terms = [
            F.cross_entropy(logits[atom_mask], atom_targets[atom_mask, index])
            for index, logits in enumerate(atom_logits)
        ]
        terms.append(torch.stack(atom_terms).mean())
    if bond_mask.any():
        bond_terms = [
            F.cross_entropy(logits[bond_mask], bond_targets[bond_mask, index])
            for index, logits in enumerate(bond_logits)
        ]
        terms.append(torch.stack(bond_terms).mean())
    if not terms:
        return atom_targets.float().sum() * 0.0
    return torch.stack(terms).mean()


def ordinal_cumulative_targets(labels: torch.Tensor, levels: int = 5) -> torch.Tensor:
    thresholds = torch.arange(1, levels, device=labels.device)
    return (labels.unsqueeze(-1) > thresholds.unsqueeze(0)).float()


def masked_ordinal_loss(
    cumulative_probabilities: torch.Tensor,
    labels: torch.Tensor,
    mask: torch.Tensor,
) -> torch.Tensor:
    if not mask.any():
        return cumulative_probabilities.sum() * 0.0
    target = ordinal_cumulative_targets(labels[mask].long(), cumulative_probabilities.size(1) + 1)
    return F.binary_cross_entropy(cumulative_probabilities[mask], target)


def masked_binary_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    mask: torch.Tensor,
    positive_weight: torch.Tensor,
) -> torch.Tensor:
    if not mask.any():
        return logits.sum() * 0.0
    return F.binary_cross_entropy_with_logits(
        logits[mask], labels[mask].float(), pos_weight=positive_weight
    )


def total_loss(
    outputs: dict[str, torch.Tensor],
    ordinal_labels: torch.Tensor,
    sensitization_labels: torch.Tensor,
    ordinal_mask: torch.Tensor,
    sensitization_mask: torch.Tensor,
    positive_weight: torch.Tensor,
    masked_reconstruction_loss: torch.Tensor,
    sensitization_weight: float = 1.0,
    mask_weight: float = 0.10,
    balance_weight: float = 0.01,
) -> dict[str, torch.Tensor]:
    ordinal = masked_ordinal_loss(outputs["cumulative"], ordinal_labels, ordinal_mask)
    sensitization = masked_binary_loss(
        outputs["sensitization_logit"],
        sensitization_labels,
        sensitization_mask,
        positive_weight,
    )
    loss = (
        ordinal
        + sensitization_weight * sensitization
        + mask_weight * masked_reconstruction_loss
        + balance_weight * outputs["balance_loss"]
    )
    return {
        "loss": loss,
        "ordinal_loss": ordinal.detach(),
        "sensitization_loss": sensitization.detach(),
        "masked_reconstruction_loss": masked_reconstruction_loss.detach(),
        "balance_loss": outputs["balance_loss"].detach(),
    }
