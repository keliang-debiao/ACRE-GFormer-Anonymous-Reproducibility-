from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


COLORS = ["#667A8A", "#A7796D", "#7E9277", "#9A8AA3", "#B39467", "#708A8A"]


def _save(figure, path: Path) -> None:
    figure.savefig(path, dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(figure)


def build_figure3(metrics_dir: Path, output_dir: Path) -> None:
    repellency = pd.read_csv(metrics_dir / "internal_repellency_cv.csv").iloc[:5]
    sensitization = pd.read_csv(metrics_dir / "internal_sensitization_cv.csv").iloc[:5]
    x = np.arange(1, 6)
    figure, axes = plt.subplots(1, 2, figsize=(10, 4))
    axes[0].plot(x, repellency["qwk"], marker="o", color=COLORS[0], label="QWK")
    axes[0].plot(x, repellency["auroc"], marker="s", color=COLORS[1], label="AUROC")
    axes[1].plot(x, sensitization["auprc"], marker="o", color=COLORS[2], label="AUPRC")
    axes[1].plot(x, sensitization["mcc"], marker="s", color=COLORS[3], label="MCC")
    for axis in axes:
        axis.set_xlabel("Outer fold")
        axis.set_xticks(x)
        axis.grid(axis="y", alpha=0.25)
        axis.legend(frameon=False)
    axes[0].set_ylabel("Metric value")
    _save(figure, output_dir / "figure3_five_fold_performance.png")


def build_figure4(metrics_dir: Path, output_dir: Path) -> None:
    frame = pd.read_csv(metrics_dir / "baseline_comparison.csv")
    frame = frame.sort_values("r_qwk")
    y = np.arange(len(frame))
    figure, axes = plt.subplots(1, 2, figsize=(12, 7), sharey=True)
    axes[0].barh(y, frame["r_qwk"], color=COLORS[0])
    axes[1].barh(y, frame["s_auprc"], color=COLORS[2])
    axes[0].set_yticks(y, frame["model"])
    axes[0].set_xlabel("Repellency QWK")
    axes[1].set_xlabel("Sensitization AUPRC")
    for axis in axes:
        axis.grid(axis="x", alpha=0.25)
    _save(figure, output_dir / "figure4_baseline_comparison.png")


def build_figure5(metrics_dir: Path, output_dir: Path) -> None:
    frame = pd.read_csv(metrics_dir / "external_transfer.csv")
    metrics = ["auroc", "auprc", "balanced_accuracy", "mcc"]
    selected = frame[frame["metric"].isin(metrics)].copy()
    figure, axis = plt.subplots(figsize=(9, 5))
    for offset, (cohort, group) in zip([-0.10, 0.10], selected.groupby("cohort", sort=False)):
        group = group.set_index("metric").loc[metrics].reset_index()
        x = np.arange(len(metrics)) + offset
        error = np.vstack(
            [group["estimate"] - group["ci_lower"], group["ci_upper"] - group["estimate"]]
        )
        axis.errorbar(x, group["estimate"], yerr=error, fmt="o", capsize=4, label=cohort)
    axis.set_xticks(np.arange(len(metrics)), [value.upper() for value in metrics])
    axis.set_ylabel("Estimate with 95% confidence interval")
    axis.grid(axis="y", alpha=0.25)
    axis.legend(frameon=False)
    _save(figure, output_dir / "figure5_external_transfer.png")


def build_figure6(metrics_dir: Path, output_dir: Path) -> None:
    frame = pd.read_csv(metrics_dir / "ablation.csv")
    full = frame.iloc[0]
    changes = frame.iloc[1:].copy()
    changes["delta_qwk"] = changes["r_qwk"] - full["r_qwk"]
    changes["delta_auprc"] = changes["s_auprc"] - full["s_auprc"]
    y = np.arange(len(changes))
    figure, axis = plt.subplots(figsize=(10, 6))
    axis.barh(y - 0.18, changes["delta_qwk"], height=0.34, label="R-QWK", color=COLORS[0])
    axis.barh(y + 0.18, changes["delta_auprc"], height=0.34, label="S-AUPRC", color=COLORS[2])
    axis.set_yticks(y, changes["configuration"])
    axis.axvline(0.0, color="#444444", linewidth=0.8)
    axis.set_xlabel("Change from full model")
    axis.legend(frameon=False)
    _save(figure, output_dir / "figure6_ablation.png")


def build_figure7(metrics_dir: Path, output_dir: Path) -> None:
    calibration = pd.read_csv(metrics_dir / "calibration.csv")
    robustness = pd.read_csv(metrics_dir / "robustness.csv")
    applicability = pd.read_csv(metrics_dir / "applicability.csv")
    figure, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    axes[0].bar(np.arange(len(calibration)), calibration["ece"], color=COLORS[0])
    axes[0].set_xticks(np.arange(len(calibration)), calibration["cohort"], rotation=70, ha="right")
    axes[0].set_ylabel("ECE")
    selected = robustness[robustness["perturbation"].isin(["Condition missingness", "Atom-feature noise"])]
    for color, (name, group) in zip(COLORS, selected.groupby("perturbation", sort=False)):
        axes[1].plot(np.arange(len(group)), group["repellency_qwk"], marker="o", color=color, label=name)
    axes[1].set_ylabel("Repellency QWK")
    axes[1].set_xlabel("Perturbation severity")
    axes[1].legend(frameon=False)
    x = np.arange(len(applicability))
    axes[2].plot(x, applicability["repellency_qwk"], marker="o", color=COLORS[0], label="R-QWK")
    axes[2].plot(x, applicability["sensitization_auprc"], marker="s", color=COLORS[2], label="S-AUPRC")
    axes[2].set_xticks(x, ["Q1", "Q2", "Q3", "Q4"])
    axes[2].set_xlabel("Scaffold-distance quartile")
    axes[2].legend(frameon=False)
    for axis in axes:
        axis.grid(axis="y", alpha=0.25)
    _save(figure, output_dir / "figure7_calibration_robustness.png")


def build_figure8(metrics_dir: Path, output_dir: Path) -> None:
    frame = pd.read_csv(metrics_dir / "statistical_comparisons.csv")
    y = np.arange(len(frame))
    difference = frame["difference"].to_numpy()
    error = np.vstack([difference - frame["ci_lower"], frame["ci_upper"] - difference])
    significant = pd.to_numeric(frame["holm_p"], errors="coerce").fillna(0.0005) < 0.05
    colors = np.where(significant, COLORS[1], "#8A8A8A")
    figure, axis = plt.subplots(figsize=(10, 5))
    for index in range(len(frame)):
        axis.errorbar(
            difference[index], y[index], xerr=error[:, index : index + 1], fmt="o", color=colors[index]
        )
    labels = frame["metric"] + " vs " + frame["comparator"]
    axis.set_yticks(y, labels)
    axis.axvline(0.0, color="#444444", linewidth=0.8)
    axis.set_xlabel("ACRE GFormer minus comparator")
    axis.grid(axis="x", alpha=0.25)
    _save(figure, output_dir / "figure8_statistical_comparisons.png")


def build_all_figures(metrics_dir: str | Path, output_dir: str | Path) -> None:
    metrics_dir = Path(metrics_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    build_figure3(metrics_dir, output_dir)
    build_figure4(metrics_dir, output_dir)
    build_figure5(metrics_dir, output_dir)
    build_figure6(metrics_dir, output_dir)
    build_figure7(metrics_dir, output_dir)
    build_figure8(metrics_dir, output_dir)
