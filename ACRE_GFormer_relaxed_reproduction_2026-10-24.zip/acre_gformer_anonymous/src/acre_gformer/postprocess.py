from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from acre_gformer.evaluation.calibration import TemperatureScaler, select_balanced_accuracy_threshold
from acre_gformer.evaluation.conformal import MondrianClassifier


ORDINAL_COLUMNS = [f"ordinal_p{level}" for level in range(1, 6)]


def probability_to_logit(probability: np.ndarray) -> np.ndarray:
    probability = np.clip(probability, 1e-7, 1.0 - 1e-7)
    return np.log(probability / (1.0 - probability))


def fit_postprocessors(calibration: pd.DataFrame, max_iter: int = 50, alpha: float = 0.10):
    repellency = calibration[calibration["task"] == "repellency_ordinal"].copy()
    sensitization = calibration[calibration["task"] == "sensitization_binary"].copy()
    ordinal_probabilities = repellency[ORDINAL_COLUMNS].to_numpy()
    ordinal_logits = torch.tensor(np.log(np.clip(ordinal_probabilities, 1e-8, 1.0)), dtype=torch.float32)
    ordinal_labels = torch.tensor(repellency["label"].to_numpy().astype(int) - 1)
    ordinal_temperature = TemperatureScaler()
    ordinal_temperature.fit_multiclass(ordinal_logits, ordinal_labels, max_iter)
    calibrated_ordinal = torch.softmax(ordinal_temperature(ordinal_logits), dim=1).detach().numpy()
    high_probability = calibrated_ordinal[:, 3:].sum(axis=1)
    high_label = (repellency["label"].to_numpy() >= 4).astype(int)
    repellency_threshold = select_balanced_accuracy_threshold(high_label, high_probability)
    repellency_conformal = MondrianClassifier(alpha).fit(
        np.column_stack([1.0 - high_probability, high_probability]), high_label
    )

    sensitization_probability = sensitization["sensitization_probability"].to_numpy()
    sensitization_logits = torch.tensor(
        probability_to_logit(sensitization_probability), dtype=torch.float32
    )
    sensitization_labels = torch.tensor(sensitization["label"].to_numpy(), dtype=torch.float32)
    sensitization_temperature = TemperatureScaler()
    sensitization_temperature.fit_binary(sensitization_logits, sensitization_labels, max_iter)
    calibrated_sensitization = torch.sigmoid(
        sensitization_temperature(sensitization_logits)
    ).detach().numpy()
    sensitization_threshold = select_balanced_accuracy_threshold(
        sensitization_labels.numpy(), calibrated_sensitization
    )
    sensitization_conformal = MondrianClassifier(alpha).fit(
        np.column_stack([1.0 - calibrated_sensitization, calibrated_sensitization]),
        sensitization_labels.numpy().astype(int),
    )
    return {
        "ordinal_temperature": float(ordinal_temperature.temperature.detach()),
        "sensitization_temperature": float(sensitization_temperature.temperature.detach()),
        "repellency_threshold": repellency_threshold,
        "sensitization_threshold": sensitization_threshold,
        "repellency_quantiles": repellency_conformal.quantiles,
        "sensitization_quantiles": sensitization_conformal.quantiles,
    }


def apply_postprocessors(predictions: pd.DataFrame, parameters: dict) -> pd.DataFrame:
    result = predictions.copy()
    ordinal_probability = result[ORDINAL_COLUMNS].to_numpy()
    ordinal_logits = torch.tensor(np.log(np.clip(ordinal_probability, 1e-8, 1.0)), dtype=torch.float32)
    ordinal_calibrated = torch.softmax(
        ordinal_logits / float(parameters["ordinal_temperature"]), dim=1
    ).numpy()
    result.loc[:, ORDINAL_COLUMNS] = ordinal_calibrated
    result["expected_ordinal"] = (ordinal_calibrated * np.arange(1, 6)).sum(axis=1)
    result["high_repellency_probability"] = ordinal_calibrated[:, 3:].sum(axis=1)
    binary_logits = torch.tensor(
        probability_to_logit(result["sensitization_probability"].to_numpy()), dtype=torch.float32
    )
    result["sensitization_probability"] = torch.sigmoid(
        binary_logits / float(parameters["sensitization_temperature"])
    ).numpy()
    result["repellency_prediction"] = (
        result["high_repellency_probability"] >= float(parameters["repellency_threshold"])
    ).astype(int)
    result["sensitization_prediction"] = (
        result["sensitization_probability"] >= float(parameters["sensitization_threshold"])
    ).astype(int)
    return result


def save_postprocessors(path: str | Path, parameters: dict) -> None:
    serializable = dict(parameters)
    serializable["repellency_quantiles"] = {
        str(key): value for key, value in parameters["repellency_quantiles"].items()
    }
    serializable["sensitization_quantiles"] = {
        str(key): value for key, value in parameters["sensitization_quantiles"].items()
    }
    Path(path).write_text(json.dumps(serializable, indent=2, sort_keys=True), encoding="utf-8")
