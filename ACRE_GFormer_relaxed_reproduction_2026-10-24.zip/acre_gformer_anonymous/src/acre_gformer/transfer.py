from __future__ import annotations

from pathlib import Path

import pandas as pd
import torch
from torch_geometric.loader import DataLoader

from acre_gformer.config import resolve_project_path
from acre_gformer.data.dataset import MolecularRecordDataset
from acre_gformer.engine import calibration_split, fit_single_model, predict
from acre_gformer.pipeline import initialize_stage
from acre_gformer.postprocess import apply_postprocessors, fit_postprocessors, save_postprocessors


def run_transfer_evaluation(config_path: str | Path) -> Path:
    config, run_dir, logger = initialize_stage(config_path, "external_transfer")
    processed = resolve_project_path(config_path, config["data"]["processed_dir"])
    development = pd.read_parquet(processed / "development.parquet")
    transfer_frames = {
        "modern": pd.read_parquet(processed / "modern_transfer.parquet"),
        "hppt": pd.read_parquet(processed / "hppt_transfer.parquet"),
    }
    fitting, calibration = calibration_split(
        development,
        float(config["split"]["calibration_fraction"]),
        int(config["project"]["seed"]),
    )
    all_predictions: dict[str, list[pd.DataFrame]] = {"modern": [], "hppt": []}
    for seed in config["training"]["seeds"]:
        checkpoint = run_dir / "checkpoints" / f"final_seed_{seed}.pt"
        model, vocabulary, calibration_predictions = fit_single_model(
            config, fitting, calibration, int(seed), checkpoint
        )
        postprocessors = fit_postprocessors(
            calibration_predictions,
            int(config["calibration"]["temperature_max_iter"]),
            float(config["calibration"]["conformal_alpha"]),
        )
        save_postprocessors(run_dir / f"final_seed_{seed}_postprocessors.json", postprocessors)
        device = next(model.parameters()).device
        for cohort, frame in transfer_frames.items():
            dataset = MolecularRecordDataset(
                frame,
                vocabulary,
                int(config["data"]["laplacian_pe_dim"]),
                int(config["data"]["distance_clip"]),
            )
            loader = DataLoader(
                dataset, batch_size=int(config["training"]["batch_size"]), shuffle=False
            )
            predictions = apply_postprocessors(predict(model, loader, device), postprocessors)
            predictions["seed"] = int(seed)
            all_predictions[cohort].append(predictions)
    numeric = [f"ordinal_p{level}" for level in range(1, 6)]
    numeric += ["expected_ordinal", "high_repellency_probability", "sensitization_probability"]
    keys = ["record_id", "entity_id", "task", "label"]
    for cohort, parts in all_predictions.items():
        stacked = pd.concat(parts, ignore_index=True)
        ensemble = stacked.groupby(keys, as_index=False)[numeric].mean()
        ensemble["ensemble_size"] = len(parts)
        ensemble.to_parquet(run_dir / f"{cohort}_ensemble_predictions.parquet", index=False)
    logger.info("status=completed modern=%d hppt=%d", len(transfer_frames["modern"]), len(transfer_frames["hppt"]))
    return run_dir
