from __future__ import annotations

from pathlib import Path

import pandas as pd

from acre_gformer.config import resolve_project_path
from acre_gformer.engine import run_outer_folds
from acre_gformer.pipeline import initialize_stage
from acre_gformer.reproducibility import write_json_atomic


def train_nested_cv(config_path: str | Path) -> Path:
    config, run_dir, logger = initialize_stage(config_path, "nested_cross_validation")
    processed = resolve_project_path(config_path, config["data"]["processed_dir"])
    development = pd.read_parquet(processed / "development.parquet")
    assignments = pd.read_csv(processed / "outer_folds.csv")
    development = development.merge(
        assignments[["record_id", "outer_fold"]], on="record_id", how="left", validate="one_to_one"
    )
    if development["outer_fold"].isna().any():
        raise ValueError("Some development records lack an outer-fold assignment")
    search_space = Path(config_path).resolve().parent / "search_space.yaml"
    predictions = run_outer_folds(config, development, run_dir, search_space)
    write_json_atomic(
        run_dir / "training_summary.json",
        {
            "records": len(development),
            "entities": int(development["entity_id"].nunique()),
            "oof_predictions": len(predictions),
            "folds": int(development["outer_fold"].nunique()),
            "seeds": config["training"]["seeds"],
        },
    )
    logger.info("status=completed oof_predictions=%d", len(predictions))
    return run_dir
