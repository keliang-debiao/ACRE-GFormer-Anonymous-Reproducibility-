from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

from acre_gformer.config import load_yaml, resolve_project_path
from acre_gformer.data.prepare import prepare_all, validate_sources
from acre_gformer.data.splits import scaffold_group_folds
from acre_gformer.reproducibility import environment_metadata, write_json_atomic
from acre_gformer.runlog import configure_logging, make_run_directory


def initialize_stage(config_path: str | Path, stage: str) -> tuple[dict[str, Any], Path, Any]:
    config_path = Path(config_path).resolve()
    config = load_yaml(config_path)
    output_root = resolve_project_path(config_path, config["project"]["output_root"])
    run_dir = make_run_directory(output_root, stage)
    shutil.copy2(config_path, run_dir / "config.yaml")
    write_json_atomic(run_dir / "environment.json", environment_metadata())
    logger = configure_logging(run_dir, f"acre_gformer.{stage}")
    logger.info("stage=%s status=started", stage)
    return config, run_dir, logger


def run_source_validation(config_path: str | Path) -> Path:
    config, run_dir, logger = initialize_stage(config_path, "source_validation")
    source_path = resolve_project_path(config_path, config["project"]["data_sources"])
    sources = load_yaml(source_path)
    raw_dir = resolve_project_path(config_path, config["data"]["raw_dir"])
    records = validate_sources(sources, raw_dir)
    write_json_atomic(run_dir / "source_audit.json", records)
    ready = sum(record["status"] == "ready" for record in records)
    logger.info("sources=%d ready=%d status=completed", len(records), ready)
    return run_dir


def run_preparation(config_path: str | Path) -> Path:
    config, run_dir, logger = initialize_stage(config_path, "data_preparation")
    project_root = Path(config_path).resolve().parent.parent
    summary = prepare_all(
        resolve_project_path(config_path, config["project"]["data_sources"]),
        project_root / "configs" / "column_map.yaml",
        resolve_project_path(config_path, config["data"]["raw_dir"]),
        resolve_project_path(config_path, config["data"]["processed_dir"]),
    )
    write_json_atomic(run_dir / "preparation_summary.json", summary)
    logger.info("status=completed summary=%s", summary)
    return run_dir


def run_split_generation(config_path: str | Path) -> Path:
    config, run_dir, logger = initialize_stage(config_path, "split_generation")
    processed = resolve_project_path(config_path, config["data"]["processed_dir"])
    frame = pd.read_parquet(processed / "development.parquet")
    frame["outer_fold"] = scaffold_group_folds(
        frame,
        n_splits=int(config["split"]["outer_folds"]),
        scaffold_column=config["data"]["scaffold_column"],
        entity_column=config["data"]["entity_column"],
        task_column=config["data"]["task_column"],
        label_column=config["data"]["label_column"],
        seed=int(config["project"]["seed"]),
    )
    columns = ["record_id", "entity_id", "scaffold", "task", "label", "outer_fold"]
    assignments = frame[columns].copy()
    assignments.to_csv(processed / "outer_folds.csv", index=False)
    counts = assignments.groupby(["outer_fold", "task"]).size().rename("records").reset_index()
    counts.to_csv(run_dir / "fold_counts.csv", index=False)
    logger.info("records=%d folds=%d status=completed", len(frame), frame["outer_fold"].nunique())
    return run_dir


def write_stage_manifest(run_dir: str | Path, payload: dict[str, Any]) -> None:
    path = Path(run_dir) / "stage_manifest.yaml"
    path.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
