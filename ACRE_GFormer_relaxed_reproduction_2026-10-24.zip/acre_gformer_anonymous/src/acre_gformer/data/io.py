from __future__ import annotations

from pathlib import Path

import pandas as pd


SUPPORTED_SUFFIXES = {".csv", ".tsv", ".txt", ".xlsx", ".xls", ".sdf", ".smi"}


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED_SUFFIXES:
        raise ValueError(f"Unsupported data suffix: {suffix}")
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if suffix == ".smi":
        return pd.read_csv(path, sep=r"\s+", names=["smiles", "record_id"], engine="python")
    from rdkit import Chem

    supplier = Chem.SDMolSupplier(str(path), removeHs=False)
    rows: list[dict[str, object]] = []
    for index, mol in enumerate(supplier):
        if mol is None:
            continue
        row = {name: mol.GetProp(name) for name in mol.GetPropNames()}
        row["smiles"] = Chem.MolToSmiles(mol, isomericSmiles=True)
        row.setdefault("record_id", str(index))
        rows.append(row)
    return pd.DataFrame(rows)


def apply_column_map(frame: pd.DataFrame, mapping: dict[str, str | None]) -> pd.DataFrame:
    missing = [key for key, source in mapping.items() if source is None]
    if missing:
        raise ValueError(f"Unresolved column mapping: {missing}")
    absent = [source for source in mapping.values() if source not in frame.columns]
    if absent:
        raise KeyError(f"Mapped source columns are absent: {absent}")
    rename = {source: target for target, source in mapping.items()}
    return frame.rename(columns=rename)[list(mapping.keys())].copy()
