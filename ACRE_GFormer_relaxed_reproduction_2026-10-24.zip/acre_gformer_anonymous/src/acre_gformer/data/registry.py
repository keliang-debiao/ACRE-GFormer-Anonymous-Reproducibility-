from __future__ import annotations

import pandas as pd

from .standardize import standardize_smiles


def build_structure_registry(frame: pd.DataFrame, structure_column: str = "smiles") -> tuple[pd.DataFrame, pd.DataFrame]:
    unique = frame[[structure_column]].drop_duplicates().reset_index(drop=True)
    records = [standardize_smiles(value).__dict__ for value in unique[structure_column].astype(str)]
    registry = pd.DataFrame(records)
    registry["entity_id"] = registry["inchikey"]
    invalid = registry.loc[~registry["valid"]].copy()
    valid_registry = registry.loc[registry["valid"]].copy()
    merged = frame.merge(
        valid_registry,
        left_on=structure_column,
        right_on="input_smiles",
        how="inner",
        validate="many_to_one",
    )
    return merged, invalid


def remove_entity_overlap(development: pd.DataFrame, transfer: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    development_ids = set(development["entity_id"].dropna().astype(str))
    overlap = transfer[transfer["entity_id"].astype(str).isin(development_ids)].copy()
    retained = transfer[~transfer["entity_id"].astype(str).isin(development_ids)].copy()
    return retained, overlap
