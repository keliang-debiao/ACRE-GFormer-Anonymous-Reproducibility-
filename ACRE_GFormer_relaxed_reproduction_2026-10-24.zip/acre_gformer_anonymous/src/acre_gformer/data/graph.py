from __future__ import annotations

import numpy as np
import torch
from rdkit import Chem
from rdkit.Chem import rdmolops
from torch_geometric.data import Data


ATOM_CARDINALITIES = [119, 12, 12, 12, 8, 2, 2, 9]
BOND_CARDINALITIES = [6, 2, 8, 2]


def _atom_features(atom: Chem.Atom) -> list[int]:
    return [
        atom.GetAtomicNum(),
        min(atom.GetTotalDegree(), 11),
        min(max(atom.GetFormalCharge() + 5, 0), 11),
        int(atom.GetChiralTag()),
        int(atom.GetHybridization()) % 8,
        int(atom.GetIsAromatic()),
        int(atom.IsInRing()),
        min(atom.GetTotalNumHs(), 8),
    ]


def _bond_features(bond: Chem.Bond | None) -> list[int]:
    if bond is None:
        return [0, 0, 0, 0]
    bond_type = {
        Chem.BondType.SINGLE: 1,
        Chem.BondType.DOUBLE: 2,
        Chem.BondType.TRIPLE: 3,
        Chem.BondType.AROMATIC: 4,
    }.get(bond.GetBondType(), 5)
    return [bond_type, int(bond.GetIsConjugated()), int(bond.GetStereo()) % 8, int(bond.IsInRing())]


def laplacian_positional_encoding(mol: Chem.Mol, dim: int) -> np.ndarray:
    adjacency = Chem.GetAdjacencyMatrix(mol).astype(np.float64)
    degree = adjacency.sum(axis=1)
    inv_sqrt = np.zeros_like(degree)
    nonzero = degree > 0
    inv_sqrt[nonzero] = 1.0 / np.sqrt(degree[nonzero])
    laplacian = np.eye(len(degree)) - inv_sqrt[:, None] * adjacency * inv_sqrt[None, :]
    _, vectors = np.linalg.eigh(laplacian)
    values = vectors[:, 1 : min(dim + 1, vectors.shape[1])]
    if values.shape[1] < dim:
        values = np.pad(values, ((0, 0), (0, dim - values.shape[1])))
    return values.astype(np.float32)


def smiles_to_graph(smiles: str, pe_dim: int = 16, distance_clip: int = 5) -> Data:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError("Invalid standardized SMILES")
    atom_x = torch.tensor([_atom_features(atom) for atom in mol.GetAtoms()], dtype=torch.long)
    distance = rdmolops.GetDistanceMatrix(mol).astype(np.int64)
    src: list[int] = []
    dst: list[int] = []
    edge_x: list[list[int]] = []
    buckets: list[int] = []
    for u in range(mol.GetNumAtoms()):
        for v in range(mol.GetNumAtoms()):
            src.append(v)
            dst.append(u)
            edge_x.append(_bond_features(mol.GetBondBetweenAtoms(v, u)))
            raw_distance = int(distance[v, u])
            buckets.append(min(raw_distance, distance_clip + 1))
    return Data(
        x=atom_x,
        edge_index=torch.tensor([src, dst], dtype=torch.long),
        edge_attr=torch.tensor(edge_x, dtype=torch.long),
        distance_bucket=torch.tensor(buckets, dtype=torch.long),
        lap_pe=torch.tensor(laplacian_positional_encoding(mol, pe_dim)),
    )
