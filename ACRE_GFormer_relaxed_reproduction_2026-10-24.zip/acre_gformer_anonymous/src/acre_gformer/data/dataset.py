from __future__ import annotations

from dataclasses import dataclass

import pandas as pd
import torch
from torch_geometric.data import Dataset

from .graph import smiles_to_graph


@dataclass
class ContextVocabulary:
    columns: list[str]
    lookup: dict[str, dict[str, int]]

    @classmethod
    def fit(cls, frame: pd.DataFrame, columns: list[str]) -> "ContextVocabulary":
        lookup: dict[str, dict[str, int]] = {}
        for column in columns:
            values = sorted(frame[column].fillna("<UNK>").astype(str).unique())
            mapping = {"<UNK>": 0}
            for value in values:
                if value != "<UNK>":
                    mapping[value] = len(mapping)
            lookup[column] = mapping
        return cls(columns, lookup)

    @property
    def cardinalities(self) -> list[int]:
        return [len(self.lookup[column]) for column in self.columns]

    def encode_row(self, row: pd.Series) -> torch.Tensor:
        indices = []
        for column in self.columns:
            value = str(row[column]) if pd.notna(row[column]) else "<UNK>"
            indices.append(self.lookup[column].get(value, 0))
        return torch.tensor([indices], dtype=torch.long)


class MolecularRecordDataset(Dataset):
    def __init__(
        self,
        frame: pd.DataFrame,
        vocabulary: ContextVocabulary,
        pe_dim: int = 16,
        distance_clip: int = 5,
    ) -> None:
        super().__init__()
        self.frame = frame.reset_index(drop=True).copy()
        self.vocabulary = vocabulary
        self.pe_dim = pe_dim
        self.distance_clip = distance_clip

    def len(self) -> int:
        return len(self.frame)

    def get(self, index: int):
        row = self.frame.iloc[index]
        graph = smiles_to_graph(row["canonical_smiles"], self.pe_dim, self.distance_clip)
        graph.context = self.vocabulary.encode_row(row)
        graph.task = str(row["task"])
        graph.label = torch.tensor([float(row["label"])], dtype=torch.float32)
        graph.entity_id = str(row["entity_id"])
        graph.record_id = str(row["record_id"])
        return graph
