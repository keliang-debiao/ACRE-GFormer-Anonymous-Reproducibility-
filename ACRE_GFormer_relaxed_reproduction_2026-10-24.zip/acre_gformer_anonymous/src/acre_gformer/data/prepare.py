from __future__ import annotations

from pathlib import Path

import pandas as pd

from acre_gformer.config import load_yaml
from acre_gformer.reproducibility import sha256_file

from .io import apply_column_map, read_table
from .registry import build_structure_registry, remove_entity_overlap


TASK_NAMES = {
    "usda_repellency": "repellency_ordinal",
    "keratinosens": "sensitization_binary",
    "modern_membrane_feeding": "repellency_transfer",
    "hppt": "sensitization_transfer",
}


def validate_sources(source_config: dict, raw_dir: str | Path) -> list[dict[str, object]]:
    raw_dir = Path(raw_dir)
    records: list[dict[str, object]] = []
    for name, details in source_config["sources"].items():
        local_file = details.get("local_file")
        if not local_file:
            records.append({"source": name, "status": "missing_local_file", "path": None})
            continue
        path = raw_dir / str(local_file)
        if not path.exists():
            records.append({"source": name, "status": "file_not_found", "path": str(path)})
            continue
        digest = sha256_file(path)
        expected = details.get("sha256")
        status = "ready" if not expected or digest == expected else "checksum_mismatch"
        records.append({"source": name, "status": status, "path": str(path), "sha256": digest})
    return records


def prepare_all(
    source_config_path: str | Path,
    column_map_path: str | Path,
    raw_dir: str | Path,
    processed_dir: str | Path,
) -> dict[str, int]:
    source_config = load_yaml(source_config_path)
    column_map = load_yaml(column_map_path)
    raw_dir = Path(raw_dir)
    processed_dir = Path(processed_dir)
    processed_dir.mkdir(parents=True, exist_ok=True)
    prepared: dict[str, pd.DataFrame] = {}
    invalid_parts: list[pd.DataFrame] = []
    for name, details in source_config["sources"].items():
        local_file = details.get("local_file")
        if not local_file:
            raise ValueError(f"local_file is unresolved for {name}")
        frame = read_table(raw_dir / str(local_file))
        frame = apply_column_map(frame, column_map[name])
        frame["task"] = TASK_NAMES[name]
        frame["source"] = frame.get("source", name).fillna(name)
        for column in ["species", "substrate", "endpoint"]:
            if column not in frame:
                frame[column] = "<UNK>"
            frame[column] = frame[column].fillna("<UNK>")
        standardized, invalid = build_structure_registry(frame, "smiles")
        invalid["source_name"] = name
        invalid_parts.append(invalid)
        prepared[name] = standardized
    development = pd.concat(
        [prepared["usda_repellency"], prepared["keratinosens"]], ignore_index=True
    )
    modern, modern_overlap = remove_entity_overlap(development, prepared["modern_membrane_feeding"])
    hppt, hppt_overlap = remove_entity_overlap(development, prepared["hppt"])
    development.to_parquet(processed_dir / "development.parquet", index=False)
    modern.to_parquet(processed_dir / "modern_transfer.parquet", index=False)
    hppt.to_parquet(processed_dir / "hppt_transfer.parquet", index=False)
    pd.concat(invalid_parts, ignore_index=True).to_csv(processed_dir / "invalid_structures.csv", index=False)
    pd.concat([modern_overlap.assign(cohort="modern"), hppt_overlap.assign(cohort="hppt")]).to_csv(
        processed_dir / "removed_transfer_overlap.csv", index=False
    )
    return {
        "development_records": len(development),
        "development_entities": development["entity_id"].nunique(),
        "modern_transfer_records": len(modern),
        "hppt_transfer_records": len(hppt),
        "removed_transfer_overlap": len(modern_overlap) + len(hppt_overlap),
    }
