"""Data ingestion, standardization, graph construction, and splitting."""
