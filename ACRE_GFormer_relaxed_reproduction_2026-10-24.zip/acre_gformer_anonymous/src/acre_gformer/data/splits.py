from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold, StratifiedGroupKFold


@dataclass(frozen=True)
class FoldAssignment:
    row_index: int
    outer_fold: int


def _stratum(frame: pd.DataFrame, task_column: str, label_column: str) -> np.ndarray:
    task = frame[task_column].astype(str)
    label = frame[label_column].astype(str)
    return (task + "::" + label).to_numpy()


def scaffold_group_folds(
    frame: pd.DataFrame,
    n_splits: int = 5,
    scaffold_column: str = "scaffold",
    entity_column: str = "entity_id",
    task_column: str = "task",
    label_column: str = "label",
    seed: int = 2026,
) -> pd.Series:
    if frame[entity_column].isna().any() or frame[scaffold_column].isna().any():
        raise ValueError("Entity and scaffold values must be complete before splitting")
    entity_to_scaffold = frame.groupby(entity_column)[scaffold_column].nunique()
    if (entity_to_scaffold > 1).any():
        raise ValueError("One entity maps to multiple scaffold groups")
    strata = _stratum(frame, task_column, label_column)
    groups = frame[scaffold_column].astype(str).to_numpy()
    folds = np.full(len(frame), -1, dtype=int)
    try:
        splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        iterator = list(splitter.split(frame, strata, groups))
    except ValueError:
        splitter = GroupKFold(n_splits=n_splits)
        iterator = list(splitter.split(frame, groups=groups))
    for fold, (_, validation_index) in enumerate(iterator):
        folds[validation_index] = fold
    if (folds < 0).any():
        raise RuntimeError("Incomplete fold assignment")
    result = pd.Series(folds, index=frame.index, name="outer_fold")
    assert_no_entity_leakage(frame.assign(outer_fold=result), entity_column, "outer_fold")
    return result


def assert_no_entity_leakage(frame: pd.DataFrame, entity_column: str, fold_column: str) -> None:
    counts = frame.groupby(entity_column)[fold_column].nunique()
    leaking = counts[counts > 1]
    if not leaking.empty:
        raise AssertionError(f"Entities cross folds: {leaking.index[:10].tolist()}")


def inner_group_folds(
    outer_training: pd.DataFrame,
    n_splits: int,
    group_column: str = "scaffold",
) -> list[tuple[np.ndarray, np.ndarray]]:
    splitter = GroupKFold(n_splits=n_splits)
    groups = outer_training[group_column].astype(str).to_numpy()
    return list(splitter.split(outer_training, groups=groups))
