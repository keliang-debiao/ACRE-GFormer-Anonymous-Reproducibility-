from __future__ import annotations

from dataclasses import dataclass

from rdkit import Chem
from rdkit.Chem.Scaffolds import MurckoScaffold
from rdkit.Chem.MolStandardize import rdMolStandardize


@dataclass(frozen=True)
class StandardizedStructure:
    input_smiles: str
    canonical_smiles: str
    inchikey: str
    scaffold: str
    valid: bool
    error: str | None = None


def standardize_smiles(smiles: str) -> StandardizedStructure:
    try:
        mol = Chem.MolFromSmiles(str(smiles), sanitize=True)
        if mol is None:
            raise ValueError("RDKit parsing returned no molecule")
        mol = rdMolStandardize.Cleanup(mol)
        fragments = rdMolStandardize.FragmentParent(mol)
        uncharger = rdMolStandardize.Uncharger()
        parent = uncharger.uncharge(fragments)
        enumerator = rdMolStandardize.TautomerEnumerator()
        parent = enumerator.Canonicalize(parent)
        Chem.AssignStereochemistry(parent, cleanIt=True, force=True)
        canonical = Chem.MolToSmiles(parent, canonical=True, isomericSmiles=True)
        inchikey = Chem.MolToInchiKey(parent)
        scaffold_mol = MurckoScaffold.GetScaffoldForMol(parent)
        scaffold = Chem.MolToSmiles(scaffold_mol, canonical=True, isomericSmiles=True)
        if not scaffold:
            scaffold = f"ACYCLIC::{inchikey}"
        return StandardizedStructure(str(smiles), canonical, inchikey, scaffold, True)
    except Exception as exc:
        return StandardizedStructure(str(smiles), "", "", "", False, str(exc))
