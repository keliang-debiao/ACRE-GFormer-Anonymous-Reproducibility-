from __future__ import annotations

import math

import numpy as np


class MondrianClassifier:
    def __init__(self, alpha: float = 0.10) -> None:
        if not 0.0 < alpha < 1.0:
            raise ValueError("alpha must lie between zero and one")
        self.alpha = alpha
        self.quantiles: dict[int, float] = {}

    def fit(self, probabilities: np.ndarray, labels: np.ndarray) -> "MondrianClassifier":
        probabilities = np.asarray(probabilities)
        labels = np.asarray(labels).astype(int)
        for label in np.unique(labels):
            selected = labels == label
            scores = 1.0 - probabilities[selected, label]
            rank = min(len(scores), math.ceil((len(scores) + 1) * (1.0 - self.alpha)))
            self.quantiles[int(label)] = float(np.sort(scores)[rank - 1])
        return self

    def predict_sets(self, probabilities: np.ndarray) -> list[list[int]]:
        if not self.quantiles:
            raise RuntimeError("MondrianClassifier must be fitted")
        result: list[list[int]] = []
        for row in np.asarray(probabilities):
            labels = [
                label
                for label, quantile in self.quantiles.items()
                if 1.0 - row[label] <= quantile
            ]
            result.append(labels)
        return result


def empirical_coverage(prediction_sets: list[list[int]], labels: np.ndarray) -> float:
    return float(np.mean([int(label) in values for label, values in zip(labels, prediction_sets)]))


def mean_set_size(prediction_sets: list[list[int]]) -> float:
    return float(np.mean([len(values) for values in prediction_sets]))
