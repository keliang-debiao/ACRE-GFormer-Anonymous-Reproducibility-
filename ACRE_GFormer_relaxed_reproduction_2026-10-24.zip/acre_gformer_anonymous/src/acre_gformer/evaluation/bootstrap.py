from __future__ import annotations

from collections.abc import Callable

import numpy as np


def clustered_bootstrap_indices(
    cluster_ids: np.ndarray,
    replicates: int = 2000,
    seed: int = 2026,
) -> list[np.ndarray]:
    cluster_ids = np.asarray(cluster_ids)
    unique = np.unique(cluster_ids)
    rng = np.random.default_rng(seed)
    result: list[np.ndarray] = []
    positions = {cluster: np.flatnonzero(cluster_ids == cluster) for cluster in unique}
    for _ in range(replicates):
        sampled = rng.choice(unique, size=len(unique), replace=True)
        result.append(np.concatenate([positions[cluster] for cluster in sampled]))
    return result


def metric_interval(
    y_true: np.ndarray,
    y_score: np.ndarray,
    cluster_ids: np.ndarray,
    metric: Callable[[np.ndarray, np.ndarray], float],
    replicates: int = 2000,
    seed: int = 2026,
    confidence: float = 0.95,
) -> tuple[float, float, float]:
    point = float(metric(y_true, y_score))
    values: list[float] = []
    for index in clustered_bootstrap_indices(cluster_ids, replicates, seed):
        try:
            values.append(float(metric(y_true[index], y_score[index])))
        except ValueError:
            continue
    lower = 100.0 * (1.0 - confidence) / 2.0
    upper = 100.0 - lower
    return point, float(np.percentile(values, lower)), float(np.percentile(values, upper))


def paired_metric_difference(
    y_true: np.ndarray,
    score_a: np.ndarray,
    score_b: np.ndarray,
    cluster_ids: np.ndarray,
    metric: Callable[[np.ndarray, np.ndarray], float],
    replicates: int = 2000,
    seed: int = 2026,
) -> dict[str, object]:
    indices = clustered_bootstrap_indices(cluster_ids, replicates, seed)
    differences: list[float] = []
    values_a: list[float] = []
    values_b: list[float] = []
    for index in indices:
        try:
            metric_a = float(metric(y_true[index], score_a[index]))
            metric_b = float(metric(y_true[index], score_b[index]))
        except ValueError:
            continue
        values_a.append(metric_a)
        values_b.append(metric_b)
        differences.append(metric_a - metric_b)
    difference = float(metric(y_true, score_a) - metric(y_true, score_b))
    lower, upper = np.percentile(differences, [2.5, 97.5])
    probability = min(np.mean(np.asarray(differences) <= 0), np.mean(np.asarray(differences) >= 0))
    raw_p = min(1.0, 2.0 * probability)
    return {
        "difference": difference,
        "ci": [float(lower), float(upper)],
        "raw_p": float(raw_p),
        "bootstrap_a": np.asarray(values_a),
        "bootstrap_b": np.asarray(values_b),
    }
