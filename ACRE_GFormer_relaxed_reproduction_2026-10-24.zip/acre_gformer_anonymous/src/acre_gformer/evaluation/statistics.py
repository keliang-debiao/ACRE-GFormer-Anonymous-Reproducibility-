from __future__ import annotations

import numpy as np


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    total = len(values)
    for rank, index in enumerate(order):
        candidate = min(1.0, (total - rank) * values[index])
        running = max(running, candidate)
        adjusted[index] = running
    return adjusted.tolist()


def cliffs_delta(values_a: np.ndarray, values_b: np.ndarray) -> float:
    values_a = np.asarray(values_a, dtype=float)
    values_b = np.asarray(values_b, dtype=float)
    greater = (values_a[:, None] > values_b[None, :]).sum()
    less = (values_a[:, None] < values_b[None, :]).sum()
    return float((greater - less) / (values_a.size * values_b.size))


def cliffs_magnitude(delta: float) -> str:
    value = abs(delta)
    if value < 0.147:
        return "negligible"
    if value < 0.330:
        return "small"
    if value < 0.474:
        return "medium"
    return "large"
