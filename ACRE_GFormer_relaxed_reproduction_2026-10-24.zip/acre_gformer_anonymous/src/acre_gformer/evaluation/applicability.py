from __future__ import annotations

import numpy as np
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem


def morgan_fingerprint(smiles: str, radius: int = 2, bits: int = 2048):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError("Invalid SMILES")
    return AllChem.GetMorganGenerator(radius=radius, fpSize=bits).GetFingerprint(mol)


def nearest_training_distance(query_smiles: str, training_smiles: list[str]) -> float:
    query = morgan_fingerprint(query_smiles)
    references = [morgan_fingerprint(value) for value in training_smiles]
    similarities = DataStructs.BulkTanimotoSimilarity(query, references)
    return float(1.0 - np.max(similarities))


def applicability_flag(distance: float, threshold: float = 0.650) -> bool:
    return bool(distance > threshold)
