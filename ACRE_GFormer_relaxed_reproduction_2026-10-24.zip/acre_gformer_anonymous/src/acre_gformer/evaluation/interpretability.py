from __future__ import annotations

import torch


def graph_integrated_gradients(
    model,
    batch,
    target_getter,
    steps: int = 64,
) -> torch.Tensor:
    model.eval()
    original = batch.lap_pe.detach()
    baseline = torch.zeros_like(original)
    accumulated = torch.zeros_like(original)
    for alpha in torch.linspace(0.0, 1.0, steps, device=original.device):
        interpolated = (baseline + alpha * (original - baseline)).requires_grad_(True)
        batch.lap_pe = interpolated
        output = target_getter(model(batch)).sum()
        gradient = torch.autograd.grad(output, interpolated, retain_graph=False)[0]
        accumulated += gradient
    batch.lap_pe = original
    return (original - baseline) * accumulated / steps


def top_k_jaccard(rankings: list[torch.Tensor], k: int = 10) -> float:
    sets = [set(torch.topk(values.abs().flatten(), min(k, values.numel())).indices.tolist()) for values in rankings]
    scores: list[float] = []
    for left in range(len(sets)):
        for right in range(left + 1, len(sets)):
            union = sets[left] | sets[right]
            scores.append(len(sets[left] & sets[right]) / len(union) if union else 1.0)
    return float(sum(scores) / len(scores)) if scores else 1.0
