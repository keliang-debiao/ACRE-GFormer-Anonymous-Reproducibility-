from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    cohen_kappa_score,
    matthews_corrcoef,
    mean_absolute_error,
    roc_auc_score,
)


def expected_calibration_error(y_true: np.ndarray, probability: np.ndarray, bins: int = 15) -> float:
    y_true = np.asarray(y_true)
    probability = np.asarray(probability)
    boundaries = np.linspace(0.0, 1.0, bins + 1)
    indices = np.minimum(np.digitize(probability, boundaries[1:-1]), bins - 1)
    error = 0.0
    for index in range(bins):
        selected = indices == index
        if selected.any():
            confidence = probability[selected].mean()
            accuracy = y_true[selected].mean()
            error += selected.mean() * abs(confidence - accuracy)
    return float(error)


def binary_metrics(y_true: np.ndarray, probability: np.ndarray, threshold: float) -> dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    probability = np.asarray(probability).astype(float)
    prediction = (probability >= threshold).astype(int)
    return {
        "auprc": float(average_precision_score(y_true, probability)),
        "auroc": float(roc_auc_score(y_true, probability)),
        "mcc": float(matthews_corrcoef(y_true, prediction)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, prediction)),
        "brier": float(brier_score_loss(y_true, probability)),
        "ece": expected_calibration_error(y_true, probability),
    }


def ordinal_metrics(y_true: np.ndarray, probabilities: np.ndarray) -> dict[str, float]:
    y_true = np.asarray(y_true).astype(int)
    probabilities = np.asarray(probabilities).astype(float)
    predicted = probabilities.argmax(axis=1) + 1
    high_true = (y_true >= 4).astype(int)
    high_probability = probabilities[:, 3:].sum(axis=1)
    return {
        "qwk": float(cohen_kappa_score(y_true, predicted, weights="quadratic")),
        "mae": float(mean_absolute_error(y_true, predicted)),
        "auroc": float(roc_auc_score(high_true, high_probability)),
        "auprc": float(average_precision_score(high_true, high_probability)),
        "brier": float(brier_score_loss(high_true, high_probability)),
        "ece": expected_calibration_error(high_true, high_probability),
    }
