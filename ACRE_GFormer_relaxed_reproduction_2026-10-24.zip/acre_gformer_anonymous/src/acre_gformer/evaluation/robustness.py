from __future__ import annotations

import numpy as np
import torch


def mask_context(context: torch.Tensor, fraction: float, unknown_index: int, seed: int) -> torch.Tensor:
    generator = torch.Generator(device=context.device).manual_seed(seed)
    selected = torch.rand(context.shape, generator=generator, device=context.device) < fraction
    result = context.clone()
    result[selected] = unknown_index
    return result


def add_feature_noise(features: torch.Tensor, scale: float, seed: int) -> torch.Tensor:
    generator = torch.Generator(device=features.device).manual_seed(seed)
    standard_deviation = features.detach().std(dim=0, keepdim=True).clamp_min(1e-8)
    noise = torch.randn(features.shape, generator=generator, device=features.device)
    return features + scale * standard_deviation * noise


def perturb_labels(labels: np.ndarray, fraction: float, classes: int, seed: int) -> np.ndarray:
    labels = np.asarray(labels).copy()
    rng = np.random.default_rng(seed)
    selected = rng.choice(len(labels), size=round(fraction * len(labels)), replace=False)
    for index in selected:
        candidates = np.delete(np.arange(classes), int(labels[index]))
        labels[index] = rng.choice(candidates)
    return labels
