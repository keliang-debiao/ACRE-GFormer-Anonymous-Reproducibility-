from __future__ import annotations

import numpy as np
import torch
from sklearn.metrics import balanced_accuracy_score


class TemperatureScaler(torch.nn.Module):
    def __init__(self, initial: float = 1.0) -> None:
        super().__init__()
        self.log_temperature = torch.nn.Parameter(torch.tensor(float(np.log(initial))))

    @property
    def temperature(self) -> torch.Tensor:
        return self.log_temperature.exp().clamp(0.05, 20.0)

    def forward(self, logits: torch.Tensor) -> torch.Tensor:
        return logits / self.temperature

    def fit_binary(self, logits: torch.Tensor, labels: torch.Tensor, max_iter: int = 50) -> float:
        logits = logits.detach()
        labels = labels.detach().float()
        optimizer = torch.optim.LBFGS([self.log_temperature], max_iter=max_iter)
        criterion = torch.nn.BCEWithLogitsLoss()

        def closure() -> torch.Tensor:
            optimizer.zero_grad()
            loss = criterion(self(logits), labels)
            loss.backward()
            return loss

        optimizer.step(closure)
        return float(self.temperature.detach())

    def fit_multiclass(self, logits: torch.Tensor, labels: torch.Tensor, max_iter: int = 50) -> float:
        logits = logits.detach()
        labels = labels.detach().long()
        optimizer = torch.optim.LBFGS([self.log_temperature], max_iter=max_iter)
        criterion = torch.nn.CrossEntropyLoss()

        def closure() -> torch.Tensor:
            optimizer.zero_grad()
            loss = criterion(self(logits), labels)
            loss.backward()
            return loss

        optimizer.step(closure)
        return float(self.temperature.detach())


def select_balanced_accuracy_threshold(y_true: np.ndarray, probability: np.ndarray) -> float:
    candidates = np.unique(np.concatenate(([0.0, 1.0], np.asarray(probability))))
    scores = [balanced_accuracy_score(y_true, probability >= threshold) for threshold in candidates]
    best = np.flatnonzero(scores == np.max(scores))
    return float(candidates[best[np.argmin(np.abs(candidates[best] - 0.5))]])
