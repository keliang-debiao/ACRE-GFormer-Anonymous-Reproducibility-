from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import optuna

from acre_gformer.config import load_yaml
from acre_gformer.data.splits import inner_group_folds
from acre_gformer.engine import fit_single_model, selection_score


def _suggest(trial: optuna.Trial, name: str, specification: dict[str, Any]):
    kind = specification["type"]
    if kind == "categorical":
        return trial.suggest_categorical(name, specification["values"])
    if kind == "float":
        return trial.suggest_float(
            name,
            float(specification["low"]),
            float(specification["high"]),
            step=specification.get("step"),
            log=bool(specification.get("log", False)),
        )
    if kind == "int":
        return trial.suggest_int(
            name,
            int(specification["low"]),
            int(specification["high"]),
            step=int(specification.get("step", 1)),
            log=bool(specification.get("log", False)),
        )
    raise KeyError(f"Unknown search-space type: {kind}")


def apply_parameters(config: dict[str, Any], values: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(config)
    model_keys = {
        "layers",
        "hidden_dim",
        "heads",
        "feedforward_dim",
        "dropout",
        "experts",
        "top_k",
    }
    training_keys = {
        "learning_rate",
        "weight_decay",
        "batch_size",
        "mask_weight",
        "balance_weight",
    }
    for key, value in values.items():
        if key in model_keys:
            result["model"][key] = value
        elif key in training_keys:
            result["training"][key] = value
    if result["model"]["hidden_dim"] % result["model"]["heads"]:
        raise optuna.TrialPruned("Hidden dimension is not divisible by attention heads")
    if result["model"]["top_k"] > result["model"]["experts"]:
        raise optuna.TrialPruned("Top-k exceeds expert count")
    return result


def tune_outer_training(
    base_config: dict[str, Any],
    outer_training,
    search_space_path: str | Path,
    work_dir: str | Path,
    outer_fold: int,
) -> dict[str, Any]:
    space = load_yaml(search_space_path)
    sampler = optuna.samplers.TPESampler(
        seed=int(space["sampler"]["seed"]) + int(outer_fold),
        multivariate=bool(space["sampler"].get("multivariate", True)),
        n_startup_trials=int(space["sampler"].get("startup_trials", 8)),
    )
    pruner = optuna.pruners.MedianPruner(
        n_startup_trials=int(space["pruner"].get("startup_trials", 8)),
        n_warmup_steps=int(space["pruner"].get("warmup_steps", 20)),
    )
    study = optuna.create_study(direction="maximize", sampler=sampler, pruner=pruner)
    inner_folds = inner_group_folds(
        outer_training,
        int(base_config["split"]["inner_folds"]),
        group_column=base_config["data"]["scaffold_column"],
    )
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    def objective(trial: optuna.Trial) -> float:
        values = {
            name: _suggest(trial, name, specification)
            for name, specification in space["parameters"].items()
        }
        config = apply_parameters(base_config, values)
        scores: list[float] = []
        for inner_fold, (training_index, validation_index) in enumerate(inner_folds):
            checkpoint = work_dir / f"trial_{trial.number}_inner_{inner_fold}.pt"
            _, _, predictions = fit_single_model(
                config,
                outer_training.iloc[training_index].copy(),
                outer_training.iloc[validation_index].copy(),
                seed=int(base_config["project"]["seed"]),
                checkpoint_path=checkpoint,
            )
            scores.append(selection_score(predictions))
            trial.report(float(np.mean(scores)), step=inner_fold)
            if trial.should_prune():
                raise optuna.TrialPruned()
        return float(np.mean(scores))

    study.optimize(objective, n_trials=int(base_config["training"]["optuna_trials"]))
    study.trials_dataframe().to_csv(work_dir / "optuna_trials.csv", index=False)
    return apply_parameters(base_config, study.best_params)
