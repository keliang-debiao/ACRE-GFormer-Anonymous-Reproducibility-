from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from acre_gformer.config import load_yaml, resolve_project_path
from acre_gformer.evaluation.statistics import cliffs_delta, cliffs_magnitude, holm_adjust
from acre_gformer.pipeline import initialize_stage
from acre_gformer.reporting import latest_stage, summarize_oof


def internal_results(config_path: str | Path) -> Path:
    config, run_dir, logger = initialize_stage(config_path, "internal_results")
    root = resolve_project_path(config_path, config["project"]["output_root"])
    training = latest_stage(root, "nested_cross_validation")
    summarize_oof(training / "oof_ensemble_predictions.parquet", run_dir)
    logger.info("status=completed")
    return run_dir


def paired_statistics(config_path: str | Path, comparison_file: str | Path) -> Path:
    _, run_dir, logger = initialize_stage(config_path, "paired_statistics")
    frame = pd.read_csv(comparison_file)
    required = {"metric", "comparator", "raw_p", "bootstrap_proposed", "bootstrap_comparator"}
    if not required.issubset(frame.columns):
        raise ValueError(f"Comparison file must contain: {sorted(required)}")
    frame["holm_p"] = holm_adjust(frame["raw_p"].tolist())
    deltas = []
    magnitudes = []
    for row in frame.itertuples(index=False):
        proposed = json.loads(row.bootstrap_proposed)
        comparator = json.loads(row.bootstrap_comparator)
        delta = cliffs_delta(proposed, comparator)
        deltas.append(delta)
        magnitudes.append(cliffs_magnitude(delta))
    frame["cliffs_delta"] = deltas
    frame["magnitude"] = magnitudes
    frame.to_csv(run_dir / "paired_comparisons.csv", index=False)
    logger.info("comparisons=%d status=completed", len(frame))
    return run_dir


def register_stage(config_path: str | Path, stage: str, inputs: list[str]) -> Path:
    _, run_dir, logger = initialize_stage(config_path, stage)
    missing = [value for value in inputs if not Path(value).exists()]
    if missing:
        raise FileNotFoundError(f"Required result artifacts are absent: {missing}")
    (run_dir / "inputs.txt").write_text("\n".join(inputs) + "\n", encoding="utf-8")
    logger.info("inputs=%d status=registered", len(inputs))
    return run_dir
