from __future__ import annotations

import argparse

from acre_gformer.pipeline import run_preparation, run_source_validation, run_split_generation


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="acre-gformer")
    subcommands = root.add_subparsers(dest="command", required=True)
    for command in ["validate-sources", "prepare-data", "make-splits"]:
        sub = subcommands.add_parser(command)
        sub.add_argument("--config", default="configs/main.yaml")
    return root


def main() -> None:
    arguments = parser().parse_args()
    if arguments.command == "validate-sources":
        run_source_validation(arguments.config)
    elif arguments.command == "prepare-data":
        run_preparation(arguments.config)
    elif arguments.command == "make-splits":
        run_split_generation(arguments.config)


if __name__ == "__main__":
    main()
