from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def molecular_descriptor_matrix(smiles: list[str], radius: int = 2, bits: int = 2048) -> np.ndarray:
    generator = AllChem.GetMorganGenerator(radius=radius, fpSize=bits)
    descriptor_functions = [
        Descriptors.MolWt,
        Descriptors.MolLogP,
        Descriptors.TPSA,
        Descriptors.NumHDonors,
        Descriptors.NumHAcceptors,
        Descriptors.NumRotatableBonds,
        Descriptors.RingCount,
        Descriptors.FractionCSP3,
    ]
    rows: list[np.ndarray] = []
    for value in smiles:
        mol = Chem.MolFromSmiles(value)
        if mol is None:
            raise ValueError("Invalid standardized SMILES")
        fingerprint = np.zeros(bits, dtype=np.float32)
        from rdkit import DataStructs

        DataStructs.ConvertToNumpyArray(generator.GetFingerprint(mol), fingerprint)
        descriptors = np.asarray([function(mol) for function in descriptor_functions], dtype=np.float32)
        rows.append(np.concatenate([fingerprint, descriptors]))
    return np.stack(rows)


def estimator_factory(name: str, seed: int) -> Any:
    if name == "logistic_regression":
        return LogisticRegression(max_iter=5000, class_weight="balanced", random_state=seed)
    if name == "random_forest":
        return RandomForestClassifier(
            n_estimators=800,
            max_features="sqrt",
            min_samples_leaf=2,
            class_weight="balanced_subsample",
            n_jobs=-1,
            random_state=seed,
        )
    if name == "mlp":
        return MLPClassifier(
            hidden_layer_sizes=(512, 256),
            alpha=1e-4,
            batch_size=128,
            learning_rate_init=2e-4,
            early_stopping=True,
            max_iter=300,
            random_state=seed,
        )
    if name == "xgboost":
        from xgboost import XGBClassifier

        return XGBClassifier(
            n_estimators=800,
            max_depth=6,
            learning_rate=0.03,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric="logloss",
            random_state=seed,
            n_jobs=-1,
        )
    if name == "lightgbm":
        from lightgbm import LGBMClassifier

        return LGBMClassifier(
            n_estimators=800,
            num_leaves=31,
            learning_rate=0.03,
            subsample=0.8,
            colsample_bytree=0.8,
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        )
    raise KeyError(f"Unsupported descriptor baseline: {name}")


@dataclass
class FoldFittedDescriptorBaseline:
    name: str
    seed: int
    pipeline: Pipeline | None = None

    def fit(self, x: np.ndarray, y: np.ndarray) -> "FoldFittedDescriptorBaseline":
        self.pipeline = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler(with_mean=False)),
                ("model", estimator_factory(self.name, self.seed)),
            ]
        )
        self.pipeline.fit(x, y)
        return self

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        if self.pipeline is None:
            raise RuntimeError("Baseline is not fitted")
        return self.pipeline.predict_proba(x)


def context_preprocessor(columns: list[str]) -> ColumnTransformer:
    return ColumnTransformer(
        [("context", OneHotEncoder(handle_unknown="ignore"), columns)],
        remainder="drop",
    )
