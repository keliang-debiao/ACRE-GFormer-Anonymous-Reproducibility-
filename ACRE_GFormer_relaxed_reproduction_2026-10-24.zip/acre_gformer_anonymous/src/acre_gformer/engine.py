from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import average_precision_score, cohen_kappa_score
from sklearn.model_selection import StratifiedGroupKFold
from torch_geometric.loader import DataLoader

from acre_gformer.data.dataset import ContextVocabulary, MolecularRecordDataset
from acre_gformer.model import ACREGFormer
from acre_gformer.reproducibility import seed_everything
from acre_gformer.postprocess import apply_postprocessors, fit_postprocessors, save_postprocessors
from acre_gformer.training import EarlyStopping, make_optimizer, save_checkpoint, train_epoch


def build_model(config: dict[str, Any], cardinalities: list[int]) -> ACREGFormer:
    model_config = config["model"]
    return ACREGFormer(
        context_cardinalities=cardinalities,
        hidden_dim=int(model_config["hidden_dim"]),
        context_field_dim=int(model_config["context_field_dim"]),
        layers=int(model_config["layers"]),
        heads=int(model_config["heads"]),
        feedforward_dim=int(model_config["feedforward_dim"]),
        distance_buckets=int(model_config["distance_buckets"]),
        experts=int(model_config["experts"]),
        top_k=int(model_config["top_k"]),
        dropout=float(model_config["dropout"]),
        pe_dim=int(config["data"]["laplacian_pe_dim"]),
        condition_in_attention=bool(model_config.get("condition_in_attention", True)),
    )


@torch.no_grad()
def predict(model, loader, device: torch.device) -> pd.DataFrame:
    model.eval()
    records: list[dict[str, object]] = []
    for batch in loader:
        batch = batch.to(device)
        output = model(batch)
        ordinal = output["class_probabilities"].detach().cpu().numpy()
        sensitization = output["sensitization_probability"].detach().cpu().numpy()
        expected = (ordinal * np.arange(1, 6)).sum(axis=1)
        for index in range(len(batch.task)):
            row: dict[str, object] = {
                "record_id": batch.record_id[index],
                "entity_id": batch.entity_id[index],
                "task": batch.task[index],
                "label": float(batch.label[index]),
                "expected_ordinal": float(expected[index]),
                "high_repellency_probability": float(ordinal[index, 3:].sum()),
                "sensitization_probability": float(sensitization[index]),
            }
            for level in range(5):
                row[f"ordinal_p{level + 1}"] = float(ordinal[index, level])
            records.append(row)
    return pd.DataFrame(records)


def selection_score(predictions: pd.DataFrame) -> float:
    repellency = predictions[predictions["task"] == "repellency_ordinal"]
    sensitization = predictions[predictions["task"] == "sensitization_binary"]
    if repellency.empty or sensitization.empty:
        raise ValueError("Both development tasks are required for model selection")
    probability_columns = [f"ordinal_p{level}" for level in range(1, 6)]
    predicted_level = repellency[probability_columns].to_numpy().argmax(axis=1) + 1
    qwk = cohen_kappa_score(repellency["label"].astype(int), predicted_level, weights="quadratic")
    auprc = average_precision_score(
        sensitization["label"].astype(int), sensitization["sensitization_probability"]
    )
    return float(0.5 * ((qwk + 1.0) / 2.0) + 0.5 * auprc)


def calibration_split(frame: pd.DataFrame, fraction: float, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    n_splits = max(2, round(1.0 / fraction))
    task_label = frame["task"].astype(str) + "::" + frame["label"].astype(str)
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    train_index, calibration_index = next(
        splitter.split(frame, task_label, groups=frame["entity_id"])
    )
    return frame.iloc[train_index].copy(), frame.iloc[calibration_index].copy()


def positive_weight(frame: pd.DataFrame) -> float:
    values = frame.loc[frame["task"] == "sensitization_binary", "label"].astype(int)
    positive = int(values.sum())
    negative = int(len(values) - positive)
    if positive == 0:
        raise ValueError("Sensitization training fold has no positive records")
    return negative / positive


def fit_single_model(
    config: dict[str, Any],
    training_frame: pd.DataFrame,
    validation_frame: pd.DataFrame,
    seed: int,
    checkpoint_path: str | Path,
) -> tuple[ACREGFormer, ContextVocabulary, pd.DataFrame]:
    seed_everything(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    context_columns = list(config["data"]["context_columns"])
    vocabulary = ContextVocabulary.fit(training_frame, context_columns)
    train_dataset = MolecularRecordDataset(
        training_frame,
        vocabulary,
        int(config["data"]["laplacian_pe_dim"]),
        int(config["data"]["distance_clip"]),
    )
    validation_dataset = MolecularRecordDataset(
        validation_frame,
        vocabulary,
        int(config["data"]["laplacian_pe_dim"]),
        int(config["data"]["distance_clip"]),
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=int(config["training"]["batch_size"]),
        shuffle=True,
    )
    validation_loader = DataLoader(
        validation_dataset,
        batch_size=int(config["training"]["batch_size"]),
        shuffle=False,
    )
    model = build_model(config, vocabulary.cardinalities).to(device)
    optimizer, scheduler = make_optimizer(model, config["training"])
    stopping = EarlyStopping(int(config["training"]["early_stopping_patience"]), mode="max")
    best_state: dict[str, torch.Tensor] | None = None
    best_predictions: pd.DataFrame | None = None
    weight = positive_weight(training_frame)
    for epoch in range(int(config["training"]["max_epochs"])):
        train_epoch(model, train_loader, optimizer, device, config["training"], epoch, weight)
        current_predictions = predict(model, validation_loader, device)
        score = selection_score(current_predictions)
        if stopping.update(score):
            best_state = copy.deepcopy(model.state_dict())
            best_predictions = current_predictions.copy()
            save_checkpoint(checkpoint_path, model, optimizer, epoch, {"seed": seed, "score": score})
        elif stopping.should_stop:
            break
        scheduler.step()
    if best_state is None or best_predictions is None:
        raise RuntimeError("Training produced no retained state")
    model.load_state_dict(best_state)
    return model, vocabulary, best_predictions


def run_outer_folds(
    config: dict[str, Any],
    frame: pd.DataFrame,
    run_dir: str | Path,
    search_space_path: str | Path | None = None,
) -> pd.DataFrame:
    run_dir = Path(run_dir)
    all_predictions: list[pd.DataFrame] = []
    seeds = [int(value) for value in config["training"]["seeds"]]
    for fold in sorted(frame["outer_fold"].unique()):
        outer_training = frame[frame["outer_fold"] != fold].copy()
        outer_validation = frame[frame["outer_fold"] == fold].copy()
        fold_config = config
        if search_space_path is not None:
            from acre_gformer.tuning import tune_outer_training

            fold_config = tune_outer_training(
                config,
                outer_training,
                search_space_path,
                run_dir / "tuning" / f"fold_{fold}",
                int(fold),
            )
        fitting, calibration = calibration_split(
            outer_training,
            float(config["split"]["calibration_fraction"]),
            seed=int(config["project"]["seed"]) + int(fold),
        )
        calibration[["record_id", "entity_id"]].to_csv(
            run_dir / f"fold_{fold}_calibration_ids.csv", index=False
        )
        seed_predictions: list[pd.DataFrame] = []
        for seed in seeds:
            checkpoint = run_dir / "checkpoints" / f"fold_{fold}_seed_{seed}.pt"
            model, vocabulary, calibration_predictions = fit_single_model(
                fold_config, fitting, calibration, seed, checkpoint
            )
            device = next(model.parameters()).device
            validation_dataset = MolecularRecordDataset(
                outer_validation,
                vocabulary,
                int(fold_config["data"]["laplacian_pe_dim"]),
                int(fold_config["data"]["distance_clip"]),
            )
            validation_loader = DataLoader(
                validation_dataset,
                batch_size=int(fold_config["training"]["batch_size"]),
                shuffle=False,
            )
            raw_predictions = predict(model, validation_loader, device)
            postprocessors = fit_postprocessors(
                calibration_predictions,
                int(fold_config["calibration"]["temperature_max_iter"]),
                float(fold_config["calibration"]["conformal_alpha"]),
            )
            predictions = apply_postprocessors(raw_predictions, postprocessors)
            calibration_predictions.to_parquet(
                run_dir / f"fold_{fold}_seed_{seed}_calibration_predictions.parquet", index=False
            )
            save_postprocessors(
                run_dir / f"fold_{fold}_seed_{seed}_postprocessors.json", postprocessors
            )
            predictions["outer_fold"] = int(fold)
            predictions["seed"] = seed
            predictions.to_parquet(
                run_dir / f"fold_{fold}_seed_{seed}_predictions.parquet", index=False
            )
            (run_dir / f"fold_{fold}_seed_{seed}_vocabulary.json").write_text(
                json.dumps(vocabulary.lookup, indent=2, sort_keys=True), encoding="utf-8"
            )
            seed_predictions.append(predictions)
        numeric = [column for column in seed_predictions[0].columns if column.startswith("ordinal_p")]
        numeric += ["expected_ordinal", "high_repellency_probability", "sensitization_probability"]
        stacked = pd.concat(seed_predictions, ignore_index=True)
        keys = ["record_id", "entity_id", "task", "label", "outer_fold"]
        ensemble = stacked.groupby(keys, as_index=False)[numeric].mean()
        ensemble["ensemble_size"] = len(seeds)
        all_predictions.append(ensemble)
    result = pd.concat(all_predictions, ignore_index=True)
    result.to_parquet(run_dir / "oof_ensemble_predictions.parquet", index=False)
    return result
