from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR, LinearLR, SequentialLR

from acre_gformer.model.losses import reconstruction_loss, total_loss


@dataclass
class EarlyStopping:
    patience: int
    mode: str = "max"
    best: float | None = None
    bad_epochs: int = 0

    def update(self, value: float) -> bool:
        better = self.best is None or (value > self.best if self.mode == "max" else value < self.best)
        if better:
            self.best = value
            self.bad_epochs = 0
            return True
        self.bad_epochs += 1
        return False

    @property
    def should_stop(self) -> bool:
        return self.bad_epochs >= self.patience


def mask_attributes(batch: Any, fraction: float, seed: int) -> tuple[Any, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    generator = torch.Generator(device=batch.x.device).manual_seed(seed)
    atom_targets = batch.x.clone()
    bond_targets = batch.edge_attr.clone()
    atom_mask = torch.rand(batch.x.size(0), generator=generator, device=batch.x.device) < fraction
    bond_mask = torch.rand(batch.edge_attr.size(0), generator=generator, device=batch.x.device) < fraction
    batch.x = batch.x.clone()
    batch.edge_attr = batch.edge_attr.clone()
    batch.x[atom_mask] = 0
    batch.edge_attr[bond_mask] = 0
    return batch, atom_targets, bond_targets, atom_mask, bond_mask


def make_optimizer(model: torch.nn.Module, config: dict[str, Any]):
    optimizer = AdamW(
        model.parameters(),
        lr=float(config["learning_rate"]),
        weight_decay=float(config["weight_decay"]),
    )
    warmup = LinearLR(optimizer, start_factor=0.1, total_iters=int(config["warmup_epochs"]))
    cosine = CosineAnnealingLR(
        optimizer, T_max=max(1, int(config["max_epochs"]) - int(config["warmup_epochs"]))
    )
    scheduler = SequentialLR(
        optimizer, [warmup, cosine], milestones=[int(config["warmup_epochs"])]
    )
    return optimizer, scheduler


def train_epoch(
    model: torch.nn.Module,
    loader,
    optimizer,
    device: torch.device,
    config: dict[str, Any],
    epoch: int,
    positive_weight: float,
) -> dict[str, float]:
    model.train()
    totals: dict[str, float] = {}
    batches = 0
    for batch_index, batch in enumerate(loader):
        batch = batch.to(device)
        batch, atom_targets, bond_targets, atom_mask, bond_mask = mask_attributes(
            batch, float(config["mask_fraction"]), seed=epoch * 100000 + batch_index
        )
        outputs = model(batch, return_reconstruction=True)
        reconstruct = reconstruction_loss(
            outputs["atom_reconstruction_logits"],
            outputs["bond_reconstruction_logits"],
            atom_targets,
            bond_targets,
            atom_mask,
            bond_mask,
        )
        task = np.asarray(batch.task)
        ordinal_mask = torch.tensor(task == "repellency_ordinal", device=device)
        sensitization_mask = torch.tensor(task == "sensitization_binary", device=device)
        labels = batch.label.view(-1)
        pieces = total_loss(
            outputs,
            labels,
            labels,
            ordinal_mask,
            sensitization_mask,
            torch.tensor(positive_weight, device=device),
            reconstruct,
            float(config["sensitization_weight"]),
            float(config["mask_weight"]),
            float(config["balance_weight"]),
        )
        optimizer.zero_grad(set_to_none=True)
        pieces["loss"].backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), float(config["gradient_clip_norm"]))
        optimizer.step()
        for key, value in pieces.items():
            totals[key] = totals.get(key, 0.0) + float(value.detach())
        batches += 1
    return {key: value / max(1, batches) for key, value in totals.items()}


def save_checkpoint(path: str | Path, model, optimizer, epoch: int, metadata: dict[str, Any]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "epoch": epoch,
            "metadata": metadata,
        },
        path,
    )
