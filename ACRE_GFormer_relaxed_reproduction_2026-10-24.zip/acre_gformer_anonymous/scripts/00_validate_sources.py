from __future__ import annotations

import argparse

from acre_gformer.pipeline import run_source_validation


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    run_source_validation(parser.parse_args().config)
