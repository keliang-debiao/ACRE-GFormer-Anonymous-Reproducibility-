from __future__ import annotations

import argparse
from acre_gformer.figures import build_all_figures


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--metrics-dir", required=True)
    parser.add_argument("--output-dir", default="outputs/figures")
    arguments = parser.parse_args()
    build_all_figures(arguments.metrics_dir, arguments.output_dir)
