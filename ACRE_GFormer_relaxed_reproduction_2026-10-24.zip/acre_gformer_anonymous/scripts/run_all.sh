#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="${1:-configs/main.yaml}"

python scripts/00_validate_sources.py --config "$CONFIG_PATH"
python scripts/01_prepare_data.py --config "$CONFIG_PATH"
python scripts/02_make_splits.py --config "$CONFIG_PATH"
python scripts/03_train_nested_cv.py --config "$CONFIG_PATH"
python scripts/04_external_transfer.py --config "$CONFIG_PATH"

echo "Core development and transfer stages completed."
echo "Run ablation, robustness, statistics, interpretability, and figure stages with their declared result inputs."
