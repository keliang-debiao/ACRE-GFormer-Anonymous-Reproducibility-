from __future__ import annotations

import argparse

from acre_gformer.experiment import train_nested_cv


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    train_nested_cv(parser.parse_args().config)
