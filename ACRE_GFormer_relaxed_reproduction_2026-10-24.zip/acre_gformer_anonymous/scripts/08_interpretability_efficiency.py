from __future__ import annotations

import argparse

from acre_gformer.stages import register_stage


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--checkpoint", required=True)
    arguments = parser.parse_args()
    register_stage(arguments.config, "interpretability_efficiency", [arguments.checkpoint])
