from __future__ import annotations

import argparse

from acre_gformer.transfer import run_transfer_evaluation


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    run_transfer_evaluation(parser.parse_args().config)
