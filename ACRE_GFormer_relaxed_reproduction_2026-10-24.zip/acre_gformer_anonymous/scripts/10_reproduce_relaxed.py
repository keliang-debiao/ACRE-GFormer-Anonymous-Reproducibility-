from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from acre_gformer.figures import build_all_figures  # noqa: E402


PROTOCOL_NAME = "relaxed_reference_target_reconstruction"
TOLERANCE = 5e-4


@dataclass(frozen=True)
class Check:
    result: str
    target: float
    reproduced: float
    tolerance: float
    source_table: str
    definition: str

    @property
    def absolute_error(self) -> float:
        return abs(self.reproduced - self.target)

    @property
    def status(self) -> str:
        return "PASS" if self.absolute_error <= self.tolerance else "FAIL"

    def row(self) -> dict[str, object]:
        result = asdict(self)
        result["absolute_error"] = self.absolute_error
        result["status"] = self.status
        return result


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require_columns(frame: pd.DataFrame, columns: set[str], filename: str) -> None:
    missing = sorted(columns - set(frame.columns))
    if missing:
        raise ValueError(f"{filename} is missing required columns: {missing}")


def metric_row(frame: pd.DataFrame, key: str, value: str) -> pd.Series:
    selected = frame[frame[key].astype(str) == value]
    if len(selected) != 1:
        raise ValueError(f"Expected one row where {key}={value!r}; found {len(selected)}")
    return selected.iloc[0]


def external_value(frame: pd.DataFrame, cohort: str, metric: str) -> float:
    selected = frame[
        (frame["cohort"].astype(str) == cohort) & (frame["metric"].astype(str) == metric)
    ]
    if len(selected) != 1:
        raise ValueError(
            f"Expected one external result for cohort={cohort!r}, metric={metric!r}; "
            f"found {len(selected)}"
        )
    return float(selected.iloc[0]["estimate"])


def load_tables(reference_dir: Path) -> dict[str, pd.DataFrame]:
    required = [
        "ablation.csv",
        "applicability.csv",
        "baseline_comparison.csv",
        "calibration.csv",
        "efficiency.csv",
        "external_transfer.csv",
        "internal_repellency_cv.csv",
        "internal_sensitization_cv.csv",
        "interpretability.csv",
        "robustness.csv",
        "statistical_comparisons.csv",
    ]
    missing = [name for name in required if not (reference_dir / name).is_file()]
    if missing:
        raise FileNotFoundError(f"Reference tables are missing: {missing}")
    return {name: pd.read_csv(reference_dir / name) for name in required}


def build_checks(tables: dict[str, pd.DataFrame]) -> list[Check]:
    repellency = tables["internal_repellency_cv.csv"]
    sensitization = tables["internal_sensitization_cv.csv"]
    external = tables["external_transfer.csv"]
    calibration = tables["calibration.csv"]
    ablation = tables["ablation.csv"]

    require_columns(
        repellency,
        {"split", "qwk", "auroc", "auprc", "mae", "brier", "ece"},
        "internal_repellency_cv.csv",
    )
    require_columns(
        sensitization,
        {"split", "auprc", "auroc", "mcc", "balanced_accuracy", "brier", "ece"},
        "internal_sensitization_cv.csv",
    )
    require_columns(
        external,
        {"cohort", "n", "positive", "negative", "metric", "estimate", "ci_lower", "ci_upper"},
        "external_transfer.csv",
    )

    rep_folds = repellency[repellency["split"].astype(str).str.startswith("fold_")]
    sen_folds = sensitization[sensitization["split"].astype(str).str.startswith("fold_")]
    if len(rep_folds) != 5 or len(sen_folds) != 5:
        raise ValueError("The relaxed protocol requires exactly five reported outer folds per task")

    rep_mean = metric_row(repellency, "split", "mean")
    rep_sd = metric_row(repellency, "split", "sd")
    sen_mean = metric_row(sensitization, "split", "mean")
    full = metric_row(ablation, "configuration", "Full ACRE GFormer")

    cal_rep = calibration[
        (calibration["cohort"] == "Repellency internal")
        & (calibration["stage"] == "Final calibrated ensemble")
    ].iloc[0]
    cal_sen = calibration[
        (calibration["cohort"] == "Sensitization internal")
        & (calibration["stage"] == "Final calibrated ensemble")
    ].iloc[0]

    return [
        Check(
            "Internal repellency QWK mean",
            float(rep_mean["qwk"]),
            float(rep_folds["qwk"].mean()),
            TOLERANCE,
            "internal_repellency_cv.csv",
            "Arithmetic mean across the five reported outer folds",
        ),
        Check(
            "Internal repellency QWK SD",
            float(rep_sd["qwk"]),
            float(rep_folds["qwk"].std(ddof=1)),
            TOLERANCE,
            "internal_repellency_cv.csv",
            "Sample SD across the five reported outer folds",
        ),
        Check(
            "Internal repellency AUROC mean",
            float(rep_mean["auroc"]),
            float(rep_folds["auroc"].mean()),
            TOLERANCE,
            "internal_repellency_cv.csv",
            "Arithmetic mean across the five reported outer folds",
        ),
        Check(
            "Internal sensitization AUPRC mean",
            float(sen_mean["auprc"]),
            float(sen_folds["auprc"].mean()),
            TOLERANCE,
            "internal_sensitization_cv.csv",
            "Arithmetic mean across the five reported outer folds",
        ),
        Check(
            "Internal sensitization MCC mean",
            float(sen_mean["mcc"]),
            float(sen_folds["mcc"].mean()),
            TOLERANCE,
            "internal_sensitization_cv.csv",
            "Arithmetic mean across the five reported outer folds",
        ),
        Check(
            "Modern transfer AUROC",
            0.752,
            external_value(external, "modern_membrane_feeding", "auroc"),
            TOLERANCE,
            "external_transfer.csv",
            "Reported point estimate",
        ),
        Check(
            "HPPT transfer AUROC",
            0.763,
            external_value(external, "hppt", "auroc"),
            TOLERANCE,
            "external_transfer.csv",
            "Reported point estimate",
        ),
        Check(
            "HPPT transfer AUPRC",
            0.387,
            external_value(external, "hppt", "auprc"),
            TOLERANCE,
            "external_transfer.csv",
            "Reported point estimate",
        ),
        Check(
            "Repellency calibrated ECE",
            0.032,
            float(cal_rep["ece"]),
            TOLERANCE,
            "calibration.csv",
            "Final calibrated ensemble",
        ),
        Check(
            "Sensitization calibrated ECE",
            0.030,
            float(cal_sen["ece"]),
            TOLERANCE,
            "calibration.csv",
            "Final calibrated ensemble",
        ),
        Check(
            "Full-model repellency QWK",
            0.640,
            float(full["r_qwk"]),
            TOLERANCE,
            "ablation.csv",
            "Full model row",
        ),
        Check(
            "Full-model sensitization AUPRC",
            0.469,
            float(full["s_auprc"]),
            TOLERANCE,
            "ablation.csv",
            "Full model row",
        ),
    ]


def write_report(output_dir: Path, checks: list[Check], figure_names: list[str]) -> None:
    passed = sum(check.status == "PASS" for check in checks)
    lines = [
        "# ACRE GFormer relaxed reproduction report",
        "",
        f"- Protocol: `{PROTOCOL_NAME}`",
        f"- Checks passed: {passed}/{len(checks)}",
        f"- Numerical tolerance: {TOLERANCE:g}",
        "- Evidence class: manuscript-aligned reference-target reconstruction",
        "",
        "This protocol is intentionally permissive. It reconstructs and audits the values supplied "
        "with the anonymous reproducibility package, then rebuilds the manuscript figures from those "
        "tables. It is not an independent retraining run from the four public raw datasets.",
        "",
        "## Numerical checks",
        "",
        "| Result | Target | Reproduced | Absolute error | Status |",
        "|---|---:|---:|---:|:---:|",
    ]
    for check in checks:
        lines.append(
            f"| {check.result} | {check.target:.6f} | {check.reproduced:.6f} | "
            f"{check.absolute_error:.6g} | {check.status} |"
        )
    lines.extend(["", "## Rebuilt figures", ""])
    lines.extend(f"- `{name}`" for name in figure_names)
    lines.extend(
        [
            "",
            "## Upgrade path",
            "",
            "To obtain formal execution evidence, populate `data/raw`, resolve exact column mappings "
            "in `configs/column_map.yaml`, record SHA-256 values in `configs/data_sources.yaml`, and "
            "run the numbered source, preparation, split, training, transfer, and reporting stages.",
            "",
        ]
    )
    (output_dir / "RELAXED_REPRODUCTION_REPORT.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def reproduce(reference_dir: Path, output_dir: Path) -> dict[str, object]:
    reference_dir = reference_dir.resolve()
    output_dir = output_dir.resolve()
    tables = load_tables(reference_dir)
    checks = build_checks(tables)

    output_dir.mkdir(parents=True, exist_ok=True)
    metrics_dir = output_dir / "metrics"
    figures_dir = output_dir / "figures"
    metrics_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    fingerprints: dict[str, str] = {}
    for name in sorted(tables):
        source = reference_dir / name
        destination = metrics_dir / name
        shutil.copy2(source, destination)
        fingerprints[name] = sha256(source)

    comparison = pd.DataFrame([check.row() for check in checks])
    comparison.to_csv(output_dir / "comparison.csv", index=False)

    build_all_figures(metrics_dir, figures_dir)
    figures = sorted(path.name for path in figures_dir.glob("*.png"))
    expected_figures = {
        "figure3_five_fold_performance.png",
        "figure4_baseline_comparison.png",
        "figure5_external_transfer.png",
        "figure6_ablation.png",
        "figure7_calibration_robustness.png",
        "figure8_statistical_comparisons.png",
    }
    if set(figures) != expected_figures:
        raise RuntimeError(f"Figure reconstruction is incomplete: {figures}")

    summary = {
        "protocol": PROTOCOL_NAME,
        "evidence_class": "reference_target_reconstruction_not_independent_raw_data_retraining",
        "reference_directory": str(reference_dir),
        "output_directory": str(output_dir),
        "tolerance": TOLERANCE,
        "checks_total": len(checks),
        "checks_passed": sum(check.status == "PASS" for check in checks),
        "all_checks_passed": all(check.status == "PASS" for check in checks),
        "figures": figures,
        "reference_sha256": fingerprints,
    }
    (output_dir / "reproduction_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )
    write_report(output_dir, checks, figures)

    if not summary["all_checks_passed"]:
        failed = [check.result for check in checks if check.status == "FAIL"]
        raise AssertionError(f"Relaxed reproduction checks failed: {failed}")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Reconstruct manuscript-aligned ACRE GFormer tables and figures."
    )
    parser.add_argument(
        "--reference-dir",
        type=Path,
        default=ROOT / "reference_outputs" / "metrics",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "outputs" / "relaxed_reproduction",
    )
    arguments = parser.parse_args()
    summary = reproduce(arguments.reference_dir, arguments.output_dir)
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
