from __future__ import annotations

import argparse

from acre_gformer.stages import paired_statistics


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--comparison-file", required=True)
    arguments = parser.parse_args()
    paired_statistics(arguments.config, arguments.comparison_file)
