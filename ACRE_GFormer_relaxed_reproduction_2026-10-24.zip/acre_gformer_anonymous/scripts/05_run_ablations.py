from __future__ import annotations

import argparse
from copy import deepcopy
from pathlib import Path

from acre_gformer.config import load_yaml
from acre_gformer.experiment import train_nested_cv


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    parser.add_argument("--ablation", required=True)
    arguments = parser.parse_args()
    base = load_yaml(arguments.config)
    ablations = load_yaml(Path(arguments.config).resolve().parent / "ablations.yaml")["ablations"]
    if arguments.ablation not in ablations:
        raise KeyError(arguments.ablation)
    selected = deepcopy(base)
    changes = ablations[arguments.ablation]
    for key, value in changes.items():
        if key in selected["model"]:
            selected["model"][key] = value
        elif key in selected["training"]:
            selected["training"][key] = value
    temporary = Path(arguments.config).resolve().parent / f"active_{arguments.ablation}.yaml"
    import yaml

    temporary.write_text(yaml.safe_dump(selected, sort_keys=False), encoding="utf-8")
    try:
        train_nested_cv(temporary)
    finally:
        temporary.unlink(missing_ok=True)
