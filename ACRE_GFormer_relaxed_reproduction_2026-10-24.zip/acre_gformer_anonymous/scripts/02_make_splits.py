from __future__ import annotations

import argparse

from acre_gformer.pipeline import run_split_generation


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/main.yaml")
    run_split_generation(parser.parse_args().config)
