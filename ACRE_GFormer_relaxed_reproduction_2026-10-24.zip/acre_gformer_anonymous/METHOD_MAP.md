# Manuscript-to-code map

| Manuscript component | Implementation |
|---|---|
| Public source audit | `data/prepare.py`, `scripts/00_validate_sources.py` |
| Structure standardization and registry | `data/standardize.py`, `data/registry.py` |
| Scaffold-aware grouped splitting | `data/splits.py`, `scripts/02_make_splits.py` |
| Molecular graph and Laplacian encoding | `data/graph.py` |
| Assay context vocabulary | `data/dataset.py`, `model/encoders.py` |
| Assay-conditioned edge-biased attention | `model/attention.py` |
| Gated graph pooling | `model/pooling.py` |
| Top-2 sparse experts | `model/experts.py` |
| Monotone ordinal-to-binary bridge | `model/heads.py` |
| Training-only reconstruction and routing loss | `model/acre.py`, `model/losses.py`, `training.py` |
| Nested selection and five-seed evaluation | `tuning.py`, `engine.py`, `experiment.py` |
| Temperature scaling and thresholds | `evaluation/calibration.py`, `postprocess.py` |
| Class-conditional conformal sets | `evaluation/conformal.py` |
| Frozen transfer evaluation | `transfer.py` |
| Clustered bootstrap and paired inference | `evaluation/bootstrap.py`, `evaluation/statistics.py` |
| Robustness operators | `evaluation/robustness.py` |
| Chemical-space applicability | `evaluation/applicability.py` |
| Graph Integrated Gradients | `evaluation/interpretability.py` |
| Fold summaries and report tables | `reporting.py`, `stages.py` |

## Forward path

The deployed path is graph and context encoding, five graph Transformer layers, gated pooling, graph-context concatenation, sparse expert routing, endpoint heads, seed averaging, temperature scaling, prediction-set construction, and applicability reporting.

Reconstruction decoders and the expert-balance penalty are activated only during training. They are not required by `predict()` and do not modify deployed outputs.

## Statistical unit

Assay records are indexed separately from molecular entities. `entity_id` identifies the standardized parent structure and is used for outer-fold grouping, overlap removal, and clustered resampling. This prevents repeated measurements of the same entity from crossing evaluation boundaries.
