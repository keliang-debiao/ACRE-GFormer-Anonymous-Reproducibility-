# Reference targets

These files record the manuscript-aligned target values used to check pipeline output shape, metric naming, rounding, and report generation. They are not original execution records and must not be cited as evidence that a computational run completed.

A formal run creates timestamped records under `outputs/`. Only those records, together with the corresponding source checksums and configuration snapshot, constitute execution evidence.
