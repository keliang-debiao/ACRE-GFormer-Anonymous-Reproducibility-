# ACRE GFormer relaxed reproduction report

- Protocol: `relaxed_reference_target_reconstruction`
- Checks passed: 12/12
- Numerical tolerance: 0.0005
- Evidence class: manuscript-aligned reference-target reconstruction

This protocol is intentionally permissive. It reconstructs and audits the values supplied with the anonymous reproducibility package, then rebuilds the manuscript figures from those tables. It is not an independent retraining run from the four public raw datasets.

## Numerical checks

| Result | Target | Reproduced | Absolute error | Status |
|---|---:|---:|---:|:---:|
| Internal repellency QWK mean | 0.640000 | 0.640000 | 0 | PASS |
| Internal repellency QWK SD | 0.009000 | 0.009028 | 2.7735e-05 | PASS |
| Internal repellency AUROC mean | 0.843000 | 0.843000 | 0 | PASS |
| Internal sensitization AUPRC mean | 0.469000 | 0.469400 | 0.0004 | PASS |
| Internal sensitization MCC mean | 0.402000 | 0.401600 | 0.0004 | PASS |
| Modern transfer AUROC | 0.752000 | 0.752000 | 0 | PASS |
| HPPT transfer AUROC | 0.763000 | 0.763000 | 0 | PASS |
| HPPT transfer AUPRC | 0.387000 | 0.387000 | 0 | PASS |
| Repellency calibrated ECE | 0.032000 | 0.032000 | 0 | PASS |
| Sensitization calibrated ECE | 0.030000 | 0.030000 | 0 | PASS |
| Full-model repellency QWK | 0.640000 | 0.640000 | 0 | PASS |
| Full-model sensitization AUPRC | 0.469000 | 0.469000 | 0 | PASS |

## Rebuilt figures

- `figure3_five_fold_performance.png`
- `figure4_baseline_comparison.png`
- `figure5_external_transfer.png`
- `figure6_ablation.png`
- `figure7_calibration_robustness.png`
- `figure8_statistical_comparisons.png`

## Upgrade path

To obtain formal execution evidence, populate `data/raw`, resolve exact column mappings in `configs/column_map.yaml`, record SHA-256 values in `configs/data_sources.yaml`, and run the numbered source, preparation, split, training, transfer, and reporting stages.
