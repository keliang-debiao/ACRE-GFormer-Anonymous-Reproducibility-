# Data contract

The source data remain outside the repository. After column mapping and structure standardization, the development and transfer tables use the following fields.

| Field | Type | Meaning |
|---|---|---|
| `record_id` | string | Source-level assay record identifier |
| `input_smiles` | string | Structure string as imported |
| `canonical_smiles` | string | Standardized isomeric canonical structure |
| `inchikey` | string | Standardized structure key |
| `entity_id` | string | Molecular grouping key; equal to standardized InChIKey |
| `scaffold` | string | Bemis-Murcko scaffold or acyclic entity key |
| `species` | string | Observed species or fixed unknown state |
| `substrate` | string | Observed substrate or fixed unknown state |
| `endpoint` | string | Assay endpoint |
| `source` | string | Source identifier |
| `task` | string | Endpoint family used by the prediction head |
| `label` | numeric | Ordinal score 1–5 or binary endpoint |
| `outer_fold` | integer | Grouped external fold index for development records |

## Required checks

1. Invalid structures are logged and excluded before graph construction.
2. Each `entity_id` maps to one canonical structure and one scaffold grouping key.
3. Every record sharing an `entity_id` remains in one outer fold.
4. Exact transfer overlap is removed before metrics are computed.
5. Missing context uses the training-defined unknown token and is never inferred from an outcome.
6. Source file checksums and parser mappings are retained in each formal run directory.
