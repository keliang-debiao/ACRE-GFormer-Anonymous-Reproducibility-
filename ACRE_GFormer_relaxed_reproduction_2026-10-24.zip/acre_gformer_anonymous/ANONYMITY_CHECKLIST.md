# Anonymous review checklist

- No author names, affiliations, email addresses, funding identifiers, or local usernames.
- No private credentials, access tokens, private data, or machine-specific absolute paths.
- Public data are referenced through official landing pages and are not redistributed.
- Source checksums are recorded after acquisition.
- All stochastic stages use declared seeds.
- Fold assignment and preprocessing are training-partition restricted.
- Reference targets are separated from run-generated evidence.
- Generated checkpoints, predictions, and logs are excluded from version control by default.
- The manuscript title and model name are consistent across configuration and documentation.
